import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface EventPlanningRequest {
  eventName: string;
  budget: number;
  currency?: string;
  eventType?: string;
  expectedAttendees?: number;
  location?: string;
}

export interface EventPlanningResponse {
  budgetBreakdown: {
    entertainment: number;
    venue: number;
    catering: number;
    marketing: number;
    decorations: number;
    miscellaneous: number;
  };
  venueRecommendations: {
    name: string;
    type: string;
    pricePerDay: number;
    capacity: number;
    location: string;
  }[];
  marketingStrategy: string[];
  timeline: {
    task: string;
    deadline: string;
    priority: "high" | "medium" | "low";
  }[];
}

export interface PricingRecommendation {
  suggestedPrice: number;
  priceRange: {
    min: number;
    max: number;
  };
  reasoning: string;
  competitorAnalysis: string;
  demandForecast: string;
}

export async function planEvent(request: EventPlanningRequest): Promise<EventPlanningResponse> {
  try {
    const prompt = `
      Plan an event called "${request.eventName}" with a budget of ${request.budget} ${request.currency || 'KES'}.
      ${request.eventType ? `Event type: ${request.eventType}` : ''}
      ${request.expectedAttendees ? `Expected attendees: ${request.expectedAttendees}` : ''}
      ${request.location ? `Location preference: ${request.location}` : 'Location: Kenya'}
      
      Provide a comprehensive event plan with:
      1. Budget breakdown across different categories
      2. Venue recommendations in Kenya with realistic pricing
      3. Marketing strategy suggestions
      4. Project timeline with tasks and priorities
      
      Focus on Kenyan venues, prices in KES, and local context.
      Respond with JSON in this exact format:
      {
        "budgetBreakdown": {
          "entertainment": number,
          "venue": number,
          "catering": number,
          "marketing": number,
          "decorations": number,
          "miscellaneous": number
        },
        "venueRecommendations": [
          {
            "name": "string",
            "type": "string",
            "pricePerDay": number,
            "capacity": number,
            "location": "string"
          }
        ],
        "marketingStrategy": ["string"],
        "timeline": [
          {
            "task": "string",
            "deadline": "string",
            "priority": "high" | "medium" | "low"
          }
        ]
      }
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert event planner in Kenya with deep knowledge of local venues, pricing, and cultural preferences. Provide detailed, actionable event planning advice."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result as EventPlanningResponse;
  } catch (error) {
    console.error("Event planning error:", error);
    throw new Error("Failed to generate event plan: " + (error as Error).message);
  }
}

export async function suggestTicketPricing(eventDetails: {
  eventType: string;
  venue: string;
  location: string;
  expectedAttendees: number;
  competitorEvents?: string[];
}): Promise<PricingRecommendation> {
  try {
    const prompt = `
      Suggest optimal ticket pricing for an event with these details:
      - Event type: ${eventDetails.eventType}
      - Venue: ${eventDetails.venue}
      - Location: ${eventDetails.location}
      - Expected attendees: ${eventDetails.expectedAttendees}
      ${eventDetails.competitorEvents ? `- Similar events: ${eventDetails.competitorEvents.join(', ')}` : ''}
      
      Consider Kenyan market conditions, local purchasing power, and competitor pricing.
      Provide pricing in KES with detailed reasoning.
      
      Respond with JSON in this format:
      {
        "suggestedPrice": number,
        "priceRange": {
          "min": number,
          "max": number
        },
        "reasoning": "string",
        "competitorAnalysis": "string",
        "demandForecast": "string"
      }
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a pricing expert for events in Kenya. You understand local market dynamics, consumer behavior, and competitive pricing strategies."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result as PricingRecommendation;
  } catch (error) {
    console.error("Pricing suggestion error:", error);
    throw new Error("Failed to suggest pricing: " + (error as Error).message);
  }
}

export async function chatWithAssistant(
  message: string,
  context: string = "general",
  chatHistory: { role: string; content: string }[] = []
): Promise<string> {
  try {
    const systemPrompts = {
      "event-planning": "You are a helpful AI assistant specializing in event planning in Kenya. Provide practical, actionable advice about venues, vendors, logistics, and event management.",
      "pricing": "You are a pricing expert for events and services in Kenya. Help users optimize their pricing strategies based on market conditions.",
      "general": "You are a friendly AI assistant for Flickshub, an event ticketing platform. Help users with questions about events, ticketing, vendors, and our platform features."
    };

    const systemPrompt = systemPrompts[context as keyof typeof systemPrompts] || systemPrompts.general;

    const messages = [
      { role: "system", content: systemPrompt },
      ...chatHistory.slice(-10), // Keep last 10 messages for context
      { role: "user", content: message }
    ];

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: messages as any,
      temperature: 0.7,
      max_tokens: 500
    });

    return response.choices[0].message.content || "I'm sorry, I couldn't process your request.";
  } catch (error) {
    console.error("Chat assistant error:", error);
    throw new Error("Failed to get response from AI assistant: " + (error as Error).message);
  }
}
