import {
  users,
  events,
  tickets,
  vendors,
  donations,
  aiChatSessions,
  type User,
  type UpsertUser,
  type Event,
  type InsertEvent,
  type Ticket,
  type InsertTicket,
  type Vendor,
  type InsertVendor,
  type Donation,
  type InsertDonation,
  type AiChatSession,
  type InsertAiChatSession,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, like, sql } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Event operations
  getEvents(filters?: { category?: string; search?: string; sponsored?: boolean }): Promise<Event[]>;
  getEvent(id: string): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: string, updates: Partial<InsertEvent>): Promise<Event>;
  getEventsByOrganizer(organizerId: string): Promise<Event[]>;
  
  // Ticket operations
  createTicket(ticket: InsertTicket): Promise<Ticket>;
  getTicket(id: string): Promise<Ticket | undefined>;
  getTicketsByUser(userId: string): Promise<Ticket[]>;
  updateTicketPaymentStatus(id: string, status: string, paymentData?: any): Promise<Ticket>;
  
  // Vendor operations
  getVendors(category?: string): Promise<Vendor[]>;
  getVendor(id: string): Promise<Vendor | undefined>;
  createVendor(vendor: InsertVendor): Promise<Vendor>;
  getVendorByUser(userId: string): Promise<Vendor | undefined>;
  
  // Donation operations
  createDonation(donation: InsertDonation): Promise<Donation>;
  getDonationsByUser(userId: string): Promise<Donation[]>;
  updateDonationStatus(id: string, status: string, paymentData?: any): Promise<Donation>;
  
  // AI Chat operations
  createChatSession(session: InsertAiChatSession): Promise<AiChatSession>;
  getChatSession(id: string): Promise<AiChatSession | undefined>;
  updateChatSession(id: string, messages: any[]): Promise<AiChatSession>;
  getChatSessionsByUser(userId: string): Promise<AiChatSession[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Event operations
  async getEvents(filters?: { category?: string; search?: string; sponsored?: boolean }): Promise<Event[]> {
    let query = db.select().from(events);
    
    const conditions = [];
    
    if (filters?.search) {
      conditions.push(
        sql`${events.title} ILIKE ${`%${filters.search}%`} OR ${events.description} ILIKE ${`%${filters.search}%`}`
      );
    }
    
    if (filters?.sponsored !== undefined) {
      conditions.push(eq(events.isSponsored, filters.sponsored));
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    const result = await query.orderBy(desc(events.isSponsored), desc(events.createdAt));
    return result;
  }

  async getEvent(id: string): Promise<Event | undefined> {
    const [event] = await db.select().from(events).where(eq(events.id, id));
    return event;
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    const [newEvent] = await db.insert(events).values(event).returning();
    return newEvent;
  }

  async updateEvent(id: string, updates: Partial<InsertEvent>): Promise<Event> {
    const [updatedEvent] = await db
      .update(events)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(events.id, id))
      .returning();
    return updatedEvent;
  }

  async getEventsByOrganizer(organizerId: string): Promise<Event[]> {
    return await db.select().from(events).where(eq(events.organizerId, organizerId));
  }

  // Ticket operations
  async createTicket(ticket: InsertTicket): Promise<Ticket> {
    const [newTicket] = await db.insert(tickets).values(ticket).returning();
    return newTicket;
  }

  async getTicket(id: string): Promise<Ticket | undefined> {
    const [ticket] = await db.select().from(tickets).where(eq(tickets.id, id));
    return ticket;
  }

  async getTicketsByUser(userId: string): Promise<Ticket[]> {
    return await db.select().from(tickets).where(eq(tickets.userId, userId));
  }

  async updateTicketPaymentStatus(id: string, status: string, paymentData?: any): Promise<Ticket> {
    const updateData: any = { paymentStatus: status };
    if (paymentData?.stripePaymentIntentId) {
      updateData.stripePaymentIntentId = paymentData.stripePaymentIntentId;
    }
    if (paymentData?.mpesaTransactionId) {
      updateData.mpesaTransactionId = paymentData.mpesaTransactionId;
    }

    const [updatedTicket] = await db
      .update(tickets)
      .set(updateData)
      .where(eq(tickets.id, id))
      .returning();
    return updatedTicket;
  }

  // Vendor operations
  async getVendors(category?: string): Promise<Vendor[]> {
    let query = db.select().from(vendors);
    
    if (category) {
      query = query.where(eq(vendors.category, category));
    }
    
    return await query.orderBy(desc(vendors.rating), desc(vendors.reviewCount));
  }

  async getVendor(id: string): Promise<Vendor | undefined> {
    const [vendor] = await db.select().from(vendors).where(eq(vendors.id, id));
    return vendor;
  }

  async createVendor(vendor: InsertVendor): Promise<Vendor> {
    const [newVendor] = await db.insert(vendors).values(vendor).returning();
    return newVendor;
  }

  async getVendorByUser(userId: string): Promise<Vendor | undefined> {
    const [vendor] = await db.select().from(vendors).where(eq(vendors.userId, userId));
    return vendor;
  }

  // Donation operations
  async createDonation(donation: InsertDonation): Promise<Donation> {
    const [newDonation] = await db.insert(donations).values(donation).returning();
    return newDonation;
  }

  async getDonationsByUser(userId: string): Promise<Donation[]> {
    return await db.select().from(donations).where(eq(donations.userId, userId));
  }

  async updateDonationStatus(id: string, status: string, paymentData?: any): Promise<Donation> {
    const updateData: any = { status };
    if (paymentData?.stripePaymentIntentId) {
      updateData.stripePaymentIntentId = paymentData.stripePaymentIntentId;
    }
    if (paymentData?.mpesaTransactionId) {
      updateData.mpesaTransactionId = paymentData.mpesaTransactionId;
    }

    const [updatedDonation] = await db
      .update(donations)
      .set(updateData)
      .where(eq(donations.id, id))
      .returning();
    return updatedDonation;
  }

  // AI Chat operations
  async createChatSession(session: InsertAiChatSession): Promise<AiChatSession> {
    const [newSession] = await db.insert(aiChatSessions).values(session).returning();
    return newSession;
  }

  async getChatSession(id: string): Promise<AiChatSession | undefined> {
    const [session] = await db.select().from(aiChatSessions).where(eq(aiChatSessions.id, id));
    return session;
  }

  async updateChatSession(id: string, messages: any[]): Promise<AiChatSession> {
    const [updatedSession] = await db
      .update(aiChatSessions)
      .set({ messages, updatedAt: new Date() })
      .where(eq(aiChatSessions.id, id))
      .returning();
    return updatedSession;
  }

  async getChatSessionsByUser(userId: string): Promise<AiChatSession[]> {
    return await db
      .select()
      .from(aiChatSessions)
      .where(eq(aiChatSessions.userId, userId))
      .orderBy(desc(aiChatSessions.updatedAt));
  }
}

export const storage = new DatabaseStorage();
