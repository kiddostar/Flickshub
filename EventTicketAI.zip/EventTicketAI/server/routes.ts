import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { planEvent, suggestTicketPricing, chatWithAssistant } from "./openai";
import { insertEventSchema, insertTicketSchema, insertVendorSchema, insertDonationSchema } from "@shared/schema";
import { z } from "zod";

// Initialize Stripe
if (!process.env.STRIPE_SECRET_KEY) {
  console.warn('STRIPE_SECRET_KEY not found, payments will not work');
}

const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-10-16",
}) : null;

// Simple auth middleware for development
const mockAuth = async (req: any, res: any, next: any) => {
  // Create a demo user if it doesn't exist
  const demoUserId = 'demo-user';
  let demoUser = await storage.getUser(demoUserId);
  
  if (!demoUser) {
    demoUser = await storage.upsertUser({
      id: demoUserId,
      email: 'demo@flickshub.com',
      firstName: 'Demo',
      lastName: 'User',
    });
  }
  
  req.user = demoUser;
  req.noAuth = () => true;
  next();
};

// Simple middleware that does nothing - just passes through
const noAuth = (req: any, res: any, next: any) => next();

export async function registerRoutes(app: Express): Promise<Server> {
  // Use simple auth for development
  app.use(mockAuth);

  // Auth routes
  app.get('/api/auth/user', async (req: any, res) => {
    try {
      res.json(req.user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Event routes
  app.get('/api/events', async (req, res) => {
    try {
      const { search, category, sponsored } = req.query;
      const filters: any = {};
      
      if (search) filters.search = search as string;
      if (category) filters.category = category as string;
      if (sponsored !== undefined) filters.sponsored = sponsored === 'true';
      
      const events = await storage.getEvents(filters);
      res.json(events);
    } catch (error) {
      console.error("Error fetching events:", error);
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });

  app.get('/api/events/:id', async (req, res) => {
    try {
      const event = await storage.getEvent(req.params.id);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      res.json(event);
    } catch (error) {
      console.error("Error fetching event:", error);
      res.status(500).json({ message: "Failed to fetch event" });
    }
  });

  app.post('/api/events', noAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      


      const eventData = insertEventSchema.parse({ ...req.body, organizerId: userId });
      const event = await storage.createEvent(eventData);
      res.json(event);
    } catch (error) {
      console.error("Error creating event:", error);
      res.status(500).json({ message: "Failed to create event" });
    }
  });

  app.get('/api/organizer/events', noAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const events = await storage.getEventsByOrganizer(userId);
      res.json(events);
    } catch (error) {
      console.error("Error fetching organizer events:", error);
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });

  // Ticket routes
  app.post('/api/tickets', noAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const ticketData = insertTicketSchema.parse({ ...req.body, userId });
      
      // Check if event exists and has capacity
      const event = await storage.getEvent(ticketData.eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      if (event.maxAttendees && event.currentAttendees >= event.maxAttendees) {
        return res.status(400).json({ message: "Event is sold out" });
      }

      const ticket = await storage.createTicket(ticketData);
      res.json(ticket);
    } catch (error) {
      console.error("Error creating ticket:", error);
      res.status(500).json({ message: "Failed to create ticket" });
    }
  });

  app.get('/api/tickets', noAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const tickets = await storage.getTicketsByUser(userId);
      res.json(tickets);
    } catch (error) {
      console.error("Error fetching tickets:", error);
      res.status(500).json({ message: "Failed to fetch tickets" });
    }
  });

  // Vendor routes
  app.get('/api/vendors', async (req, res) => {
    try {
      const { category } = req.query;
      const vendors = await storage.getVendors(category as string);
      res.json(vendors);
    } catch (error) {
      console.error("Error fetching vendors:", error);
      res.status(500).json({ message: "Failed to fetch vendors" });
    }
  });

  app.post('/api/vendors', noAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const vendorData = insertVendorSchema.parse({ ...req.body, userId });
      const vendor = await storage.createVendor(vendorData);
      res.json(vendor);
    } catch (error) {
      console.error("Error creating vendor:", error);
      res.status(500).json({ message: "Failed to create vendor profile" });
    }
  });

  app.get('/api/vendor/profile', noAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const vendor = await storage.getVendorByUser(userId);
      res.json(vendor);
    } catch (error) {
      console.error("Error fetching vendor profile:", error);
      res.status(500).json({ message: "Failed to fetch vendor profile" });
    }
  });

  // Donation routes
  app.post('/api/donations', async (req, res) => {
    try {
      const donationData = insertDonationSchema.parse(req.body);
      const donation = await storage.createDonation(donationData);
      res.json(donation);
    } catch (error) {
      console.error("Error creating donation:", error);
      res.status(500).json({ message: "Failed to create donation" });
    }
  });

  app.get('/api/donations', noAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const donations = await storage.getDonationsByUser(userId);
      res.json(donations);
    } catch (error) {
      console.error("Error fetching donations:", error);
      res.status(500).json({ message: "Failed to fetch donations" });
    }
  });

  // AI Assistant routes
  app.post('/api/ai/plan-event', noAuth, async (req, res) => {
    try {
      const { eventName, budget, currency, eventType, expectedAttendees, location } = req.body;
      
      if (!eventName || !budget) {
        return res.status(400).json({ message: "Event name and budget are required" });
      }

      const plan = await planEvent({
        eventName,
        budget: parseFloat(budget),
        currency,
        eventType,
        expectedAttendees: expectedAttendees ? parseInt(expectedAttendees) : undefined,
        location
      });

      res.json(plan);
    } catch (error) {
      console.error("Error planning event:", error);
      res.status(500).json({ message: "Failed to generate event plan" });
    }
  });

  app.post('/api/ai/suggest-pricing', noAuth, async (req, res) => {
    try {
      const { eventType, venue, location, expectedAttendees, competitorEvents } = req.body;
      
      if (!eventType || !venue || !location || !expectedAttendees) {
        return res.status(400).json({ message: "Missing required fields for pricing suggestion" });
      }

      const pricing = await suggestTicketPricing({
        eventType,
        venue,
        location,
        expectedAttendees: parseInt(expectedAttendees),
        competitorEvents
      });

      res.json(pricing);
    } catch (error) {
      console.error("Error suggesting pricing:", error);
      res.status(500).json({ message: "Failed to suggest pricing" });
    }
  });

  app.post('/api/ai/chat', async (req, res) => {
    try {
      const { message, context, sessionId } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      let chatHistory: any[] = [];
      
      if (sessionId) {
        const session = await storage.getChatSession(sessionId);
        if (session) {
          chatHistory = session.messages || [];
        }
      }

      const response = await chatWithAssistant(message, context, chatHistory);
      
      // Update chat history
      const newMessages = [
        ...chatHistory,
        { role: "user", content: message },
        { role: "assistant", content: response }
      ];

      if (sessionId) {
        await storage.updateChatSession(sessionId, newMessages);
      }

      res.json({ response, sessionId });
    } catch (error) {
      console.error("Error in AI chat:", error);
      res.status(500).json({ message: "Failed to get AI response" });
    }
  });

  app.post('/api/ai/chat/session', noAuth, async (req: any, res) => {
    try {
      const userId = req.user.id;
      const { context } = req.body;
      
      const session = await storage.createChatSession({
        userId,
        context: context || "general",
        messages: []
      });

      res.json(session);
    } catch (error) {
      console.error("Error creating chat session:", error);
      res.status(500).json({ message: "Failed to create chat session" });
    }
  });

  // Stripe payment routes
  if (stripe) {
    app.post("/api/create-payment-intent", async (req, res) => {
      try {
        const { amount, currency = "kes", ticketId, donationAmount } = req.body;
        
        if (!amount) {
          return res.status(400).json({ message: "Amount is required" });
        }

        const totalAmount = parseFloat(amount) + (donationAmount ? parseFloat(donationAmount) : 0);
        
        const paymentIntent = await stripe.paymentIntents.create({
          amount: Math.round(totalAmount * 100), // Convert to cents
          currency: currency.toLowerCase(),
          metadata: {
            ticketId: ticketId || "",
            donationAmount: donationAmount || "0"
          }
        });

        res.json({ clientSecret: paymentIntent.client_secret });
      } catch (error: any) {
        console.error("Stripe payment intent error:", error);
        res.status(500).json({ message: "Error creating payment intent: " + error.message });
      }
    });

    app.post("/api/create-donation-intent", async (req, res) => {
      try {
        const { amount, currency = "kes" } = req.body;
        
        if (!amount) {
          return res.status(400).json({ message: "Amount is required" });
        }

        const paymentIntent = await stripe.paymentIntents.create({
          amount: Math.round(parseFloat(amount) * 100), // Convert to cents
          currency: currency.toLowerCase(),
          metadata: {
            type: "donation"
          }
        });

        res.json({ clientSecret: paymentIntent.client_secret });
      } catch (error: any) {
        console.error("Stripe donation intent error:", error);
        res.status(500).json({ message: "Error creating donation intent: " + error.message });
      }
    });

    // Webhook for payment confirmation
    app.post('/api/webhooks/stripe', async (req, res) => {
      try {
        const event = req.body;
        
        if (event.type === 'payment_intent.succeeded') {
          const paymentIntent = event.data.object;
          const { ticketId, donationAmount, type } = paymentIntent.metadata;
          
          if (type === "donation") {
            // Handle donation payment
            await storage.updateDonationStatus(paymentIntent.id, "completed", {
              stripePaymentIntentId: paymentIntent.id
            });
          } else if (ticketId) {
            // Handle ticket payment
            await storage.updateTicketPaymentStatus(ticketId, "completed", {
              stripePaymentIntentId: paymentIntent.id
            });

            if (donationAmount && parseFloat(donationAmount) > 0) {
              // Create donation record for round-up
              await storage.createDonation({
                amount: donationAmount,
                type: "round-up",
                paymentMethod: "stripe",
                stripePaymentIntentId: paymentIntent.id,
                ticketId,
                status: "completed"
              });
            }
          }
        }
        
        res.json({ received: true });
      } catch (error) {
        console.error("Webhook error:", error);
        res.status(500).json({ message: "Webhook processing failed" });
      }
    });
  } else {
    // Mock payment endpoints when Stripe is not configured
    app.post("/api/create-payment-intent", async (req, res) => {
      res.status(503).json({ message: "Payment service not configured" });
    });

    app.post("/api/create-donation-intent", async (req, res) => {
      res.status(503).json({ message: "Payment service not configured" });
    });
  }

  const httpServer = createServer(app);
  return httpServer;
}
