import { useEffect } from "react";
import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import Footer from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Calculator, 
  MapPin, 
  TrendingUp, 
  Headphones, 
  Utensils, 
  Car, 
  Music, 
  Megaphone,
  GraduationCap,
  Heart,
  Sprout,
  Star
} from "lucide-react";

export default function Landing() {
  useEffect(() => {
    document.title = "Flickshub - Event Ticketing & AI Planning Platform";
  }, []);

  const featuredEvents = [
    {
      id: "1",
      title: "AfroKenya Music Festival",
      description: "Experience the best of African music with top artists from across the continent",
      date: "March 15, 2024",
      venue: "Kasarani Stadium",
      price: "KES 2,500",
      imageUrl: "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      isSponsored: true,
      isTrending: true,
      countdown: { days: 23, hours: 14, minutes: 32 }
    },
    {
      id: "2",
      title: "Tech Summit Nairobi 2024",
      description: "Join East Africa's largest technology conference featuring industry leaders",
      date: "April 5, 2024",
      venue: "KICC",
      price: "KES 5,000",
      imageUrl: "https://images.unsplash.com/photo-1511795409834-ef04bbd61622?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      isSponsored: true,
      stockLeft: 10,
      countdown: { days: 44, hours: 8, minutes: 15 }
    },
    {
      id: "3",
      title: "Hope Foundation Gala",
      description: "An elegant evening supporting children's education across Kenya",
      date: "March 28, 2024",
      venue: "Serena Hotel",
      price: "KES 8,000",
      imageUrl: "https://images.unsplash.com/photo-1559027615-cd4628902d4a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=400",
      isSponsored: true,
      isCharity: true,
      countdown: { days: 36, hours: 22, minutes: 47 }
    }
  ];

  const weeklyEvents = [
    {
      title: "Jazz Night Live",
      venue: "Blue Note Lounge",
      price: "KES 1,200",
      imageUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
    },
    {
      title: "Modern Art Expo",
      venue: "National Gallery",
      price: "KES 800",
      imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
    },
    {
      title: "Street Food Festival",
      venue: "Central Park",
      price: "KES 500",
      imageUrl: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
    },
    {
      title: "Comedy Night",
      venue: "Laugh Factory",
      price: "KES 1,500",
      imageUrl: "https://images.unsplash.com/photo-1516131206008-dd041a9764fd?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250"
    }
  ];

  const aiFeatures = [
    {
      icon: Calculator,
      title: "Smart Budget Planning",
      description: "Get optimal budget breakdowns and cost-saving recommendations based on your event type and goals."
    },
    {
      icon: MapPin,
      title: "Venue Recommendations",
      description: "Discover perfect venues in Kenya with real-time availability, pricing, and detailed insights."
    },
    {
      icon: TrendingUp,
      title: "Dynamic Pricing",
      description: "AI-powered ticket pricing optimization based on demand patterns and competitor analysis."
    },
    {
      icon: Headphones,
      title: "24/7 Support",
      description: "Get instant answers about dress codes, parking, schedules, and any event-related questions."
    }
  ];

  const serviceCategories = [
    {
      icon: Utensils,
      title: "Food & Catering",
      description: "Professional catering services from local favorites to gourmet experiences",
      priceFrom: "KES 500/person",
      color: "bg-orange-100 text-orange-600"
    },
    {
      icon: Car,
      title: "Transportation",
      description: "Seamless transport solutions including Uber partnership and shuttle services",
      priceFrom: "15% Discount",
      color: "bg-blue-100 text-blue-600"
    },
    {
      icon: Music,
      title: "Entertainment",
      description: "DJs, live bands, sound equipment, and lighting for unforgettable experiences",
      priceFrom: "KES 15,000",
      color: "bg-purple-100 text-purple-600"
    },
    {
      icon: Megaphone,
      title: "Marketing",
      description: "Social media promotion, poster design, and digital marketing campaigns",
      priceFrom: "KES 5,000",
      color: "bg-green-100 text-green-600"
    }
  ];

  const impactStats = [
    { icon: GraduationCap, label: "Children Helped", value: "500+", color: "text-green-600" },
    { icon: Heart, label: "Communities", value: "25", color: "text-blue-600" },
    { icon: Sprout, label: "Funds Raised", value: "KES 2.5M", color: "text-primary" }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <HeroSection />
      
      {/* Featured Events Section */}
      <section className="py-16 bg-muted/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-foreground mb-4">Featured Events</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Don't miss out on these incredible experiences happening near you
            </p>
          </div>

          {/* Sponsored Events */}
          <div className="mb-12">
            <div className="flex items-center mb-6">
              <Star className="text-primary text-xl mr-2" />
              <h3 className="text-2xl font-bold text-foreground">Sponsored Events</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredEvents.map((event) => (
                <Card key={event.id} className="bg-card border-2 border-primary card-hover">
                  <div className="relative">
                    <img 
                      src={event.imageUrl} 
                      alt={event.title}
                      className="w-full h-48 object-cover rounded-t-lg"
                    />
                    <div className="absolute top-4 left-4">
                      {event.isTrending && (
                        <Badge className="bg-red-500 text-white animate-pulse-slow">
                          <Star className="w-3 h-3 mr-1" />
                          Trending
                        </Badge>
                      )}
                      {event.stockLeft && (
                        <Badge className="bg-yellow-500 text-white animate-pulse-slow">
                          {event.stockLeft}% Left
                        </Badge>
                      )}
                      {event.isCharity && (
                        <Badge className="bg-green-500 text-white">
                          <Heart className="w-3 h-3 mr-1" />
                          Charity
                        </Badge>
                      )}
                    </div>
                    <div className="absolute top-4 right-4">
                      <Badge className="bg-primary text-primary-foreground">
                        SPONSORED
                      </Badge>
                    </div>
                  </div>
                  
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold text-card-foreground mb-2">{event.title}</h3>
                    <p className="text-muted-foreground mb-4">{event.description}</p>
                    
                    <div className="flex items-center mb-4 text-sm text-muted-foreground">
                      <span>{event.date}</span>
                      <span className="mx-2">•</span>
                      <span>{event.venue}</span>
                    </div>

                    {/* Countdown Timer */}
                    <div className="bg-muted rounded-lg p-4 mb-4">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground mb-2">Event starts in:</p>
                        <div className="flex justify-center space-x-4 text-primary font-bold">
                          <div className="text-center">
                            <div className="text-2xl">{event.countdown.days}</div>
                            <div className="text-xs">DAYS</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl">{event.countdown.hours}</div>
                            <div className="text-xs">HRS</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl">{event.countdown.minutes}</div>
                            <div className="text-xs">MIN</div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-2xl font-bold text-primary">{event.price}</p>
                        <p className="text-sm text-muted-foreground">From</p>
                      </div>
                      <Button className="btn-primary" asChild>
                        <a href="/api/login">Buy Ticket</a>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Regular Events */}
          <div className="mb-8">
            <h3 className="text-2xl font-bold text-foreground mb-6">Happening This Week</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {weeklyEvents.map((event, index) => (
                <Card key={index} className="card-hover">
                  <div className="relative">
                    <img 
                      src={event.imageUrl} 
                      alt={event.title}
                      className="w-full h-40 object-cover rounded-t-lg"
                    />
                  </div>
                  <CardContent className="p-4">
                    <h4 className="font-semibold text-card-foreground mb-1">{event.title}</h4>
                    <p className="text-sm text-muted-foreground mb-2">{event.venue}</p>
                    <p className="text-lg font-bold text-primary">{event.price}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div className="text-center">
            <Button variant="outline" className="hover:bg-muted" asChild>
              <a href="/api/login">
                View All Events
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* AI Assistant Preview Section */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-foreground mb-4">Meet Your AI Event Assistant</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Plan perfect events with intelligent recommendations, budget optimization, and real-time assistance
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* AI Chat Interface Demo */}
            <div className="bg-muted rounded-2xl p-8">
              <div className="bg-card rounded-xl shadow-md p-6 h-96 overflow-y-auto">
                <div className="space-y-4">
                  <div className="flex justify-end">
                    <div className="bg-primary text-primary-foreground px-4 py-2 rounded-lg max-w-xs">
                      Plan an event called Afrokenya, I have a budget of 100k
                    </div>
                  </div>

                  <div className="flex justify-start">
                    <div className="bg-muted text-foreground px-4 py-2 rounded-lg max-w-sm">
                      <p className="mb-2">Great! I'll help you plan AfroKenya. Here's my budget breakdown for KES 100,000:</p>
                      <div className="text-sm space-y-1">
                        <div className="flex justify-between">
                          <span>🎵 Entertainment:</span>
                          <span className="font-semibold">KES 35,000</span>
                        </div>
                        <div className="flex justify-between">
                          <span>📍 Venue:</span>
                          <span className="font-semibold">KES 25,000</span>
                        </div>
                        <div className="flex justify-between">
                          <span>🍽️ Catering:</span>
                          <span className="font-semibold">KES 20,000</span>
                        </div>
                        <div className="flex justify-between">
                          <span>📢 Marketing:</span>
                          <span className="font-semibold">KES 15,000</span>
                        </div>
                        <div className="flex justify-between">
                          <span>🎭 Decorations:</span>
                          <span className="font-semibold">KES 5,000</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* AI Features */}
            <div className="space-y-8">
              {aiFeatures.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div key={index} className="flex items-start space-x-4">
                    <div className="bg-primary text-primary-foreground p-3 rounded-full">
                      <Icon className="h-6 w-6" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-foreground mb-2">{feature.title}</h3>
                      <p className="text-muted-foreground">{feature.description}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Marketplace Section */}
      <section className="py-16 bg-muted/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-foreground mb-4">Event Services Marketplace</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Connect with trusted vendors and partners to make your event extraordinary
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            {serviceCategories.map((category, index) => {
              const Icon = category.icon;
              return (
                <Card key={index} className="text-center card-hover">
                  <CardContent className="p-6">
                    <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${category.color}`}>
                      <Icon className="h-8 w-8" />
                    </div>
                    <h3 className="text-xl font-semibold text-card-foreground mb-2">{category.title}</h3>
                    <p className="text-muted-foreground mb-4 text-sm">{category.description}</p>
                    <div className="text-sm text-muted-foreground mb-4">
                      <div className="flex justify-between">
                        <span>Starting from:</span>
                        <span className="font-semibold text-primary">{category.priceFrom}</span>
                      </div>
                    </div>
                    <Button className="w-full btn-primary" asChild>
                      <a href="/api/login">Explore</a>
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="bg-gradient-to-r from-primary to-primary/80 rounded-2xl p-8 text-primary-foreground text-center">
            <h3 className="text-2xl font-bold mb-4">Partner with Uber for Seamless Transportation</h3>
            <p className="text-lg mb-6 opacity-90">
              Exclusive discounts for event attendees with direct app integration
            </p>
            <Button variant="secondary" asChild>
              <a href="/api/login">Get Started</a>
            </Button>
          </div>
        </div>
      </section>

      {/* Foundation Section */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-foreground mb-4">Flickshub Foundation</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Making a difference in communities across Kenya, one event at a time
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h3 className="text-3xl font-bold text-foreground mb-6">Our Impact</h3>
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-green-100 p-3 rounded-full">
                    <GraduationCap className="text-green-600 h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Education Support</h4>
                    <p className="text-muted-foreground">Supporting over 500 children with school fees, supplies, and educational programs across rural Kenya.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-blue-100 p-3 rounded-full">
                    <Heart className="text-blue-600 h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Healthcare Access</h4>
                    <p className="text-muted-foreground">Mobile health clinics and medical camps reaching remote communities with essential healthcare services.</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="bg-primary/20 p-3 rounded-full">
                    <Sprout className="text-primary h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-foreground mb-2">Community Development</h4>
                    <p className="text-muted-foreground">Clean water projects, sustainable agriculture training, and economic empowerment programs.</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 mt-8 p-6 bg-muted rounded-xl">
                {impactStats.map((stat, index) => {
                  const Icon = stat.icon;
                  return (
                    <div key={index} className="text-center">
                      <Icon className={`h-8 w-8 mx-auto mb-2 ${stat.color}`} />
                      <div className="text-2xl font-bold text-primary">{stat.value}</div>
                      <div className="text-sm text-muted-foreground">{stat.label}</div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <img 
                src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Children's Home Visit"
                className="rounded-xl shadow-lg w-full h-48 object-cover"
              />
              <img 
                src="https://images.unsplash.com/photo-1593113598332-cd288d649433?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Community Project"
                className="rounded-xl shadow-lg w-full h-48 object-cover"
              />
              <img 
                src="https://images.unsplash.com/photo-1559027615-cd4628902d4a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Healthcare Outreach"
                className="rounded-xl shadow-lg w-full h-48 object-cover"
              />
              <img 
                src="https://images.unsplash.com/photo-1497486751825-1233686d5d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Education Support"
                className="rounded-xl shadow-lg w-full h-48 object-cover"
              />
            </div>
          </div>

          <div className="text-center">
            <Button className="btn-primary text-lg px-8 py-4" asChild>
              <a href="/api/login">Join Our Mission</a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
