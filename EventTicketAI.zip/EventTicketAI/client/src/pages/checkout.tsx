import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import MobileNav from "@/components/mobile-nav";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { 
  CreditCard, 
  Smartphone, 
  Heart, 
  CheckCircle, 
  AlertCircle, 
  Calendar, 
  MapPin, 
  Ticket,
  ArrowLeft,
  Shield,
  Clock
} from "lucide-react";

// Make sure to call `loadStripe` outside of a component's render to avoid recreating the `Stripe` object on every render.
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  console.warn('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}

const stripePromise = import.meta.env.VITE_STRIPE_PUBLIC_KEY 
  ? loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY)
  : Promise.resolve(null);

const CheckoutForm = ({ ticket, event, onSuccess }: { ticket: any, event: any, onSuccess: () => void }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements || isProcessing) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/dashboard?tab=tickets`,
        },
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Payment Successful",
          description: "Your tickets have been confirmed!",
        });
        onSuccess();
      }
    } catch (error) {
      toast({
        title: "Payment Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="border border-border rounded-lg p-4">
        <PaymentElement />
      </div>
      
      <Button 
        type="submit" 
        disabled={!stripe || !elements || isProcessing}
        className="w-full btn-primary text-lg py-3"
      >
        {isProcessing ? (
          <>
            <div className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full mr-2" />
            Processing Payment...
          </>
        ) : (
          <>
            <Shield className="mr-2 h-5 w-5" />
            Complete Payment
          </>
        )}
      </Button>
    </form>
  );
};

export default function Checkout() {
  const [match, params] = useRoute("/checkout/:ticketId?");
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [paymentMethod, setPaymentMethod] = useState<"stripe" | "mpesa">("stripe");
  const [donationAmount, setDonationAmount] = useState("");
  const [roundUpDonation, setRoundUpDonation] = useState(false);
  const [clientSecret, setClientSecret] = useState("");
  const [paymentComplete, setPaymentComplete] = useState(false);

  useEffect(() => {
    document.title = "Checkout - Flickshub";
    
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to complete your purchase.",
        variant: "destructive"
      });
      window.location.href = "/api/login";
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  // Fetch ticket details
  const { data: ticket, isLoading: ticketLoading, error: ticketError } = useQuery({
    queryKey: ["/api/tickets", params?.ticketId],
    queryFn: async () => {
      if (!params?.ticketId) throw new Error("No ticket ID provided");
      const response = await fetch(`/api/tickets/${params.ticketId}`);
      if (!response.ok) throw new Error("Failed to fetch ticket");
      return response.json();
    },
    enabled: !!params?.ticketId && isAuthenticated
  });

  // Fetch event details if we have a ticket
  const { data: event, isLoading: eventLoading } = useQuery({
    queryKey: ["/api/events", ticket?.eventId],
    queryFn: async () => {
      const response = await fetch(`/api/events/${ticket.eventId}`);
      if (!response.ok) throw new Error("Failed to fetch event");
      return response.json();
    },
    enabled: !!ticket?.eventId
  });

  // Create payment intent
  const createPaymentMutation = useMutation({
    mutationFn: async (paymentData: any) => {
      if (paymentMethod === "stripe") {
        const response = await apiRequest("POST", "/api/create-payment-intent", paymentData);
        return response.json();
      } else {
        // Handle M-Pesa payment
        toast({
          title: "M-Pesa Integration",
          description: "M-Pesa payment will be implemented in the next update.",
        });
        throw new Error("M-Pesa payment not yet implemented");
      }
    },
    onSuccess: (data) => {
      if (data.clientSecret) {
        setClientSecret(data.clientSecret);
      }
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      toast({
        title: "Payment Setup Failed",
        description: error.message || "Please try again.",
        variant: "destructive"
      });
    }
  });

  useEffect(() => {
    if (ticket && event && !clientSecret && paymentMethod === "stripe") {
      const totals = calculateTotal();
      createPaymentMutation.mutate({
        amount: totals.ticketTotal,
        ticketId: ticket.id,
        donationAmount: totals.donationTotal > 0 ? totals.donationTotal : undefined
      });
    }
  }, [ticket, event, paymentMethod, donationAmount, roundUpDonation]);

  const calculateTotal = () => {
    if (!ticket || !event) return { ticketTotal: 0, donationTotal: 0, grandTotal: 0 };
    
    const ticketPrice = parseFloat(ticket.totalAmount);
    let donationTotal = 0;

    if (roundUpDonation) {
      const roundedUp = Math.ceil(ticketPrice / 100) * 100;
      donationTotal = roundedUp - ticketPrice;
    } else if (donationAmount) {
      donationTotal = parseFloat(donationAmount) || 0;
    }

    return {
      ticketTotal: ticketPrice,
      donationTotal,
      grandTotal: ticketPrice + donationTotal
    };
  };

  const formatDate = (date: string | Date) => {
    return new Intl.DateTimeFormat("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    }).format(new Date(date));
  };

  const handlePaymentSuccess = () => {
    setPaymentComplete(true);
    queryClient.invalidateQueries({ queryKey: ["/api/tickets"] });
    
    setTimeout(() => {
      window.location.href = "/dashboard?tab=tickets";
    }, 3000);
  };

  if (authLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <div className="spinner mx-auto mb-4" />
          <p className="text-muted-foreground">Verifying authentication...</p>
        </div>
        <Footer />
      </div>
    );
  }

  if (!params?.ticketId) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <AlertCircle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-foreground mb-2">Invalid Checkout</h1>
          <p className="text-muted-foreground mb-4">No ticket information provided.</p>
          <Button asChild>
            <Link href="/events">Browse Events</Link>
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  if (paymentComplete) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <CheckCircle className="h-24 w-24 text-green-500 mx-auto mb-6" />
          <h1 className="text-3xl font-bold text-foreground mb-4">Payment Successful!</h1>
          <p className="text-lg text-muted-foreground mb-6">
            Your tickets have been confirmed. You'll be redirected to your dashboard shortly.
          </p>
          <div className="flex items-center justify-center text-muted-foreground">
            <Clock className="h-5 w-5 mr-2" />
            <span>Redirecting in 3 seconds...</span>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (ticketError) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <AlertCircle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-foreground mb-2">Ticket Not Found</h1>
          <p className="text-muted-foreground mb-4">The ticket you're trying to checkout doesn't exist.</p>
          <Button asChild>
            <Link href="/events">Browse Events</Link>
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  const totals = calculateTotal();

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <Button variant="ghost" asChild className="mb-4">
            <Link href={event ? `/events/${event.id}` : "/events"}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Event
            </Link>
          </Button>
          <h1 className="text-3xl font-bold text-foreground">Checkout</h1>
          <p className="text-muted-foreground">Complete your ticket purchase</p>
        </div>

        {ticketLoading || eventLoading ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <Skeleton className="h-6 w-48" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-32 w-full" />
                </CardContent>
              </Card>
            </div>
            <div>
              <Card>
                <CardHeader>
                  <Skeleton className="h-6 w-32" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-48 w-full" />
                </CardContent>
              </Card>
            </div>
          </div>
        ) : ticket && event ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Checkout Form */}
            <div className="lg:col-span-2 space-y-6">
              {/* Event Summary */}
              <Card>
                <CardHeader>
                  <CardTitle>Event Details</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-start space-x-4">
                    {event.imageUrl && (
                      <img
                        src={event.imageUrl}
                        alt={event.title}
                        className="w-20 h-20 object-cover rounded-lg"
                      />
                    )}
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-foreground">{event.title}</h3>
                      <div className="flex items-center text-muted-foreground mt-2 space-x-4">
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-1" />
                          <span className="text-sm">{formatDate(event.date)}</span>
                        </div>
                        <div className="flex items-center">
                          <MapPin className="h-4 w-4 mr-1" />
                          <span className="text-sm">{event.venue}</span>
                        </div>
                      </div>
                      <div className="flex items-center mt-2">
                        <Ticket className="h-4 w-4 mr-1 text-primary" />
                        <span className="text-sm font-medium">
                          {ticket.quantity} ticket{ticket.quantity > 1 ? 's' : ''}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Method Selection */}
              <Card>
                <CardHeader>
                  <CardTitle>Payment Method</CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod as any}>
                    <div className="flex items-center space-x-2 p-4 border border-border rounded-lg">
                      <RadioGroupItem value="stripe" id="stripe" />
                      <Label htmlFor="stripe" className="flex items-center flex-1 cursor-pointer">
                        <CreditCard className="h-5 w-5 mr-3 text-blue-600" />
                        <div>
                          <div className="font-medium">Credit/Debit Card</div>
                          <div className="text-sm text-muted-foreground">Secure payment with Stripe</div>
                        </div>
                      </Label>
                      <Badge variant="secondary">Recommended</Badge>
                    </div>
                    
                    <div className="flex items-center space-x-2 p-4 border border-border rounded-lg opacity-60">
                      <RadioGroupItem value="mpesa" id="mpesa" disabled />
                      <Label htmlFor="mpesa" className="flex items-center flex-1">
                        <Smartphone className="h-5 w-5 mr-3 text-green-600" />
                        <div>
                          <div className="font-medium">M-Pesa</div>
                          <div className="text-sm text-muted-foreground">Coming soon</div>
                        </div>
                      </Label>
                      <Badge variant="outline">Coming Soon</Badge>
                    </div>
                  </RadioGroup>
                </CardContent>
              </Card>

              {/* Donation Options */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Heart className="h-5 w-5 mr-2 text-red-500" />
                    Support Our Foundation
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Add a donation to support local communities across Kenya
                  </p>
                  
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="roundup"
                        checked={roundUpDonation}
                        onCheckedChange={(checked) => {
                          setRoundUpDonation(checked);
                          if (checked) setDonationAmount("");
                        }}
                      />
                      <Label htmlFor="roundup" className="text-sm">
                        Round up to nearest KES 100 
                        {roundUpDonation && totals.donationTotal > 0 && (
                          <span className="text-primary font-medium">
                            {" "}(+KES {totals.donationTotal.toLocaleString()})
                          </span>
                        )}
                      </Label>
                    </div>
                    
                    <div>
                      <Label htmlFor="donation" className="text-sm">Custom Donation Amount</Label>
                      <Input
                        id="donation"
                        type="number"
                        placeholder="Enter amount in KES"
                        value={donationAmount}
                        onChange={(e) => {
                          setDonationAmount(e.target.value);
                          if (e.target.value) setRoundUpDonation(false);
                        }}
                        disabled={roundUpDonation}
                        className="mt-1"
                        min="0"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Form */}
              {paymentMethod === "stripe" && clientSecret && (
                <Card>
                  <CardHeader>
                    <CardTitle>Payment Information</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Elements stripe={stripePromise} options={{ clientSecret }}>
                      <CheckoutForm 
                        ticket={ticket} 
                        event={event} 
                        onSuccess={handlePaymentSuccess}
                      />
                    </Elements>
                  </CardContent>
                </Card>
              )}

              {paymentMethod === "stripe" && !clientSecret && (
                <Card>
                  <CardContent className="p-6">
                    <div className="text-center">
                      <div className="spinner mx-auto mb-4" />
                      <p className="text-muted-foreground">Setting up secure payment...</p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Order Summary Sidebar */}
            <div>
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span>Tickets ({ticket.quantity}x)</span>
                      <span>{event.currency} {totals.ticketTotal.toLocaleString()}</span>
                    </div>
                    
                    {totals.donationTotal > 0 && (
                      <div className="flex justify-between text-green-600">
                        <span className="flex items-center">
                          <Heart className="h-4 w-4 mr-1" />
                          Donation
                        </span>
                        <span>{event.currency} {totals.donationTotal.toLocaleString()}</span>
                      </div>
                    )}
                    
                    <Separator />
                    
                    <div className="flex justify-between font-semibold text-lg">
                      <span>Total</span>
                      <span className="text-primary">{event.currency} {totals.grandTotal.toLocaleString()}</span>
                    </div>
                  </div>

                  <div className="bg-muted/50 p-4 rounded-lg">
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Shield className="h-4 w-4 mr-2" />
                      <span>Secure payment powered by Stripe</span>
                    </div>
                  </div>

                  <div className="text-xs text-muted-foreground">
                    <p>
                      By completing your purchase, you agree to our Terms of Service and Privacy Policy.
                      Tickets are non-refundable except as required by law.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        ) : null}
      </div>

      <Footer />
      <MobileNav />
    </div>
  );
}
