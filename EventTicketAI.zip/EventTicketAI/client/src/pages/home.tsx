import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import MobileNav from "@/components/mobile-nav";
import EventCard from "@/components/event-card";
import AiChat from "@/components/ai-chat";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { 
  Search, 
  Plus, 
  Calendar, 
  TrendingUp, 
  Users, 
  Heart,
  Star,
  ArrowRight,
  Bot,
  Sparkles
} from "lucide-react";
import type { Event } from "@shared/schema";

export default function Home() {
  useEffect(() => {
    document.title = "Flickshub - Discover Amazing Events";
  }, []);

  const { data: sponsoredEvents, isLoading: sponsoredLoading } = useQuery({
    queryKey: ["/api/events", { sponsored: true }],
    queryFn: () => fetch("/api/events?sponsored=true").then(res => res.json())
  });

  const { data: trendingEvents, isLoading: trendingLoading } = useQuery({
    queryKey: ["/api/events", { trending: true }],
    queryFn: () => fetch("/api/events?limit=8").then(res => res.json())
  });

  const quickStats = [
    { icon: Calendar, label: "Events This Month", value: "150+", color: "text-blue-600" },
    { icon: Users, label: "Active Users", value: "25K+", color: "text-green-600" },
    { icon: Heart, label: "Community Impact", value: "KES 2.5M", color: "text-red-600" },
    { icon: TrendingUp, label: "Success Rate", value: "98%", color: "text-primary" }
  ];

  const aiFeatures = [
    {
      title: "Smart Event Planning",
      description: "Get AI-powered recommendations for venues, budgets, and timelines",
      icon: Bot,
      action: "Try AI Planner"
    },
    {
      title: "Dynamic Pricing",
      description: "Optimize ticket prices with market analysis and demand forecasting",
      icon: TrendingUp,
      action: "Get Pricing"
    },
    {
      title: "Instant Support",
      description: "24/7 AI assistant for event questions and attendee support",
      icon: Sparkles,
      action: "Ask Assistant"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary/10 via-background to-primary/5 pt-8 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
              Welcome to <span className="gradient-text">Flickshub</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Your gateway to unforgettable experiences. Discover events, connect with communities, and create lasting memories.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button className="btn-primary text-lg px-8 py-3" asChild>
                <Link href="/events">
                  <Search className="mr-2 h-5 w-5" />
                  Explore Events
                </Link>
              </Button>
              <Button variant="outline" className="text-lg px-8 py-3" asChild>
                <Link href="/create-event">
                  <Plus className="mr-2 h-5 w-5" />
                  Create Event
                </Link>
              </Button>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
              {quickStats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <Card key={index} className="text-center">
                    <CardContent className="p-4">
                      <Icon className={`h-8 w-8 mx-auto mb-2 ${stat.color}`} />
                      <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                      <div className="text-sm text-muted-foreground">{stat.label}</div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Sponsored Events */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center">
              <Star className="text-primary h-6 w-6 mr-2" />
              <h2 className="text-3xl font-bold text-foreground">Featured Events</h2>
            </div>
            <Button variant="outline" asChild>
              <Link href="/events?sponsored=true">
                View All <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>

          {sponsoredLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {Array.from({ length: 3 }).map((_, i) => (
                <Card key={i}>
                  <Skeleton className="h-48 w-full" />
                  <CardContent className="p-6">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full mb-4" />
                    <Skeleton className="h-4 w-1/2" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : sponsoredEvents?.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {sponsoredEvents.slice(0, 3).map((event: Event) => (
                <EventCard 
                  key={event.id} 
                  event={event} 
                  variant="featured" 
                  showCountdown={true}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Calendar className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">No Featured Events</h3>
              <p className="text-muted-foreground">Check back soon for exciting sponsored events!</p>
            </div>
          )}
        </div>
      </section>

      {/* AI Features Preview */}
      <section className="py-16 bg-muted/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">AI-Powered Event Solutions</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Harness the power of artificial intelligence to plan, price, and manage your events like never before
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {aiFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="text-center card-hover">
                  <CardContent className="p-6">
                    <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Icon className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-3">{feature.title}</h3>
                    <p className="text-muted-foreground mb-4">{feature.description}</p>
                    <Button variant="outline" className="w-full">
                      {feature.action}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Trending Events */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold text-foreground">Trending Events</h2>
            <Button variant="outline" asChild>
              <Link href="/events">
                View All <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>

          {trendingLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {Array.from({ length: 8 }).map((_, i) => (
                <Card key={i}>
                  <Skeleton className="h-40 w-full" />
                  <CardContent className="p-4">
                    <Skeleton className="h-5 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-1/2 mb-2" />
                    <Skeleton className="h-5 w-1/3" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : trendingEvents?.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {trendingEvents.slice(0, 8).map((event: Event) => (
                <EventCard key={event.id} event={event} variant="compact" />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <TrendingUp className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">No Trending Events</h3>
              <p className="text-muted-foreground">Be the first to discover exciting new events!</p>
            </div>
          )}
        </div>
      </section>

      {/* Quick Actions */}
      <section className="py-16 bg-primary/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center card-hover">
              <CardContent className="p-8">
                <Search className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-foreground mb-3">Find Events</h3>
                <p className="text-muted-foreground mb-6">
                  Discover amazing events happening in your area
                </p>
                <Button className="btn-primary w-full" asChild>
                  <Link href="/events">Browse Events</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="text-center card-hover">
              <CardContent className="p-8">
                <Users className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-foreground mb-3">Connect Services</h3>
                <p className="text-muted-foreground mb-6">
                  Find trusted vendors for your event needs
                </p>
                <Button className="btn-primary w-full" asChild>
                  <Link href="/marketplace">Explore Marketplace</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="text-center card-hover">
              <CardContent className="p-8">
                <Heart className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-foreground mb-3">Make Impact</h3>
                <p className="text-muted-foreground mb-6">
                  Support communities through our foundation
                </p>
                <Button className="btn-primary w-full" asChild>
                  <Link href="/foundation">Learn More</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
      <MobileNav />
      <AiChat context="general" />
    </div>
  );
}
