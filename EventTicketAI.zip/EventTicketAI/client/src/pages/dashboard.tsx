import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import MobileNav from "@/components/mobile-nav";
import EventCard from "@/components/event-card";
import AiChat from "@/components/ai-chat";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { 
  User, 
  Ticket, 
  Calendar, 
  BarChart3, 
  Settings, 
  Heart,
  MapPin,
  Clock,
  Users,
  DollarSign,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Star,
  Edit,
  Trash2,
  Eye,
  Plus,
  Download,
  Mail,
  Phone
} from "lucide-react";
import type { Event, Ticket as TicketType, Donation } from "@shared/schema";

export default function Dashboard() {
  const [location] = useLocation();
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [activeTab, setActiveTab] = useState("overview");
  const [profileData, setProfileData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    bio: ""
  });

  useEffect(() => {
    document.title = "Dashboard - Flickshub";
    
    // Parse URL parameters for tab
    const params = new URLSearchParams(window.location.search);
    const tab = params.get("tab");
    if (tab) setActiveTab(tab);
    
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to access your dashboard.",
        variant: "destructive"
      });
      window.location.href = "/api/login";
      return;
    }
  }, [isAuthenticated, authLoading, toast, location]);

  useEffect(() => {
    if (user) {
      setProfileData({
        firstName: user.firstName || "",
        lastName: user.lastName || "",
        email: user.email || "",
        phone: "",
        bio: ""
      });
    }
  }, [user]);

  // Fetch user tickets
  const { data: tickets, isLoading: ticketsLoading } = useQuery({
    queryKey: ["/api/tickets"],
    enabled: isAuthenticated,
    retry: false
  });

  // Fetch user events (for organizers)
  const { data: userEvents, isLoading: eventsLoading } = useQuery({
    queryKey: ["/api/organizer/events"],
    enabled: isAuthenticated && (user?.role === "organizer" || user?.role === "admin"),
    retry: false
  });

  // Fetch user donations
  const { data: donations, isLoading: donationsLoading } = useQuery({
    queryKey: ["/api/donations"],
    enabled: isAuthenticated,
    retry: false
  });

  // Fetch vendor profile (for vendors)
  const { data: vendorProfile, isLoading: vendorLoading } = useQuery({
    queryKey: ["/api/vendor/profile"],
    enabled: isAuthenticated && user?.role === "vendor",
    retry: false
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("PATCH", "/api/auth/user", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
    onError: (error: Error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update profile",
        variant: "destructive"
      });
    }
  });

  const handleProfileUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfileMutation.mutate(profileData);
  };

  const formatDate = (date: string | Date) => {
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    }).format(new Date(date));
  };

  const getTicketStatus = (ticket: TicketType) => {
    switch (ticket.paymentStatus) {
      case "completed":
        return { label: "Confirmed", color: "bg-green-500", icon: CheckCircle };
      case "pending":
        return { label: "Pending", color: "bg-yellow-500", icon: Clock };
      case "failed":
        return { label: "Failed", color: "bg-red-500", icon: AlertCircle };
      default:
        return { label: "Unknown", color: "bg-gray-500", icon: AlertCircle };
    }
  };

  const calculateStats = () => {
    const totalTickets = tickets?.length || 0;
    const totalSpent = tickets?.reduce((sum: number, ticket: TicketType) => 
      sum + parseFloat(ticket.totalAmount), 0) || 0;
    const totalDonations = donations?.reduce((sum: number, donation: Donation) => 
      sum + parseFloat(donation.amount), 0) || 0;
    const upcomingEvents = tickets?.filter((ticket: TicketType) => {
      // Would need to join with events to check dates
      return ticket.paymentStatus === "completed";
    }).length || 0;

    return { totalTickets, totalSpent, totalDonations, upcomingEvents };
  };

  const stats = calculateStats();

  if (authLoading || !isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 py-16 text-center">
          <div className="spinner mx-auto mb-4" />
          <p className="text-muted-foreground">Loading dashboard...</p>
        </div>
        <Footer />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-7xl mx-auto px-4 py-16 text-center">
          <AlertCircle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-foreground mb-2">Unable to Load Profile</h1>
          <p className="text-muted-foreground mb-4">Please try refreshing the page.</p>
          <Button onClick={() => window.location.reload()}>Refresh</Button>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center space-x-4 mb-6">
            <Avatar className="h-16 w-16">
              <AvatarImage src={user.profileImageUrl} alt={user.firstName} />
              <AvatarFallback className="text-lg">
                {user.firstName?.[0]}{user.lastName?.[0]}
              </AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-3xl font-bold text-foreground">
                Welcome back, {user.firstName}!
              </h1>
              <p className="text-muted-foreground capitalize">
                {user.role} • Member since {formatDate(user.createdAt || new Date())}
              </p>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <Ticket className="h-8 w-8 mx-auto mb-2 text-primary" />
                <div className="text-2xl font-bold text-foreground">{stats.totalTickets}</div>
                <div className="text-sm text-muted-foreground">Total Tickets</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <DollarSign className="h-8 w-8 mx-auto mb-2 text-green-600" />
                <div className="text-2xl font-bold text-foreground">KES {stats.totalSpent.toLocaleString()}</div>
                <div className="text-sm text-muted-foreground">Total Spent</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Heart className="h-8 w-8 mx-auto mb-2 text-red-500" />
                <div className="text-2xl font-bold text-foreground">KES {stats.totalDonations.toLocaleString()}</div>
                <div className="text-sm text-muted-foreground">Donated</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Calendar className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                <div className="text-2xl font-bold text-foreground">{stats.upcomingEvents}</div>
                <div className="text-sm text-muted-foreground">Upcoming</div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 lg:grid-cols-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="tickets">My Tickets</TabsTrigger>
            {(user.role === "organizer" || user.role === "admin") && (
              <TabsTrigger value="events">My Events</TabsTrigger>
            )}
            <TabsTrigger value="donations">Donations</TabsTrigger>
            {user.role === "vendor" && (
              <TabsTrigger value="vendor">Vendor Profile</TabsTrigger>
            )}
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Tickets */}
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle>Recent Tickets</CardTitle>
                  <Button variant="outline" size="sm" onClick={() => setActiveTab("tickets")}>
                    View All
                  </Button>
                </CardHeader>
                <CardContent>
                  {ticketsLoading ? (
                    <div className="space-y-3">
                      {Array.from({ length: 3 }).map((_, i) => (
                        <div key={i} className="flex items-center space-x-3">
                          <Skeleton className="h-12 w-12 rounded" />
                          <div className="flex-1">
                            <Skeleton className="h-4 w-3/4 mb-2" />
                            <Skeleton className="h-3 w-1/2" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : tickets?.length > 0 ? (
                    <div className="space-y-3">
                      {tickets.slice(0, 3).map((ticket: TicketType) => {
                        const status = getTicketStatus(ticket);
                        const StatusIcon = status.icon;
                        return (
                          <div key={ticket.id} className="flex items-center space-x-3 p-3 border border-border rounded-lg">
                            <div className={`p-2 rounded-full ${status.color} text-white`}>
                              <StatusIcon className="h-4 w-4" />
                            </div>
                            <div className="flex-1">
                              <div className="font-medium">Event Ticket</div>
                              <div className="text-sm text-muted-foreground">
                                {ticket.quantity} ticket{ticket.quantity > 1 ? 's' : ''} • KES {parseFloat(ticket.totalAmount).toLocaleString()}
                              </div>
                            </div>
                            <Badge variant="secondary">{status.label}</Badge>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-6">
                      <Ticket className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                      <p className="text-muted-foreground">No tickets yet</p>
                      <Button variant="outline" size="sm" className="mt-2" asChild>
                        <a href="/events">Browse Events</a>
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button className="w-full justify-start" variant="outline" asChild>
                    <a href="/events">
                      <Calendar className="mr-2 h-4 w-4" />
                      Browse Events
                    </a>
                  </Button>
                  
                  {(user.role === "organizer" || user.role === "admin") && (
                    <Button className="w-full justify-start btn-primary" asChild>
                      <a href="/create-event">
                        <Plus className="mr-2 h-4 w-4" />
                        Create New Event
                      </a>
                    </Button>
                  )}
                  
                  <Button className="w-full justify-start" variant="outline" asChild>
                    <a href="/foundation">
                      <Heart className="mr-2 h-4 w-4" />
                      Make a Donation
                    </a>
                  </Button>
                  
                  <Button className="w-full justify-start" variant="outline" asChild>
                    <a href="/marketplace">
                      <Users className="mr-2 h-4 w-4" />
                      Find Vendors
                    </a>
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Tickets Tab */}
          <TabsContent value="tickets" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>My Tickets</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Manage your event tickets and view attendance history
                </p>
              </CardHeader>
              <CardContent>
                {ticketsLoading ? (
                  <div className="space-y-4">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <div key={i} className="flex items-center space-x-4 p-4 border border-border rounded-lg">
                        <Skeleton className="h-16 w-16 rounded" />
                        <div className="flex-1">
                          <Skeleton className="h-5 w-3/4 mb-2" />
                          <Skeleton className="h-4 w-1/2 mb-1" />
                          <Skeleton className="h-3 w-1/3" />
                        </div>
                        <Skeleton className="h-8 w-20" />
                      </div>
                    ))}
                  </div>
                ) : tickets?.length > 0 ? (
                  <div className="space-y-4">
                    {tickets.map((ticket: TicketType) => {
                      const status = getTicketStatus(ticket);
                      const StatusIcon = status.icon;
                      return (
                        <div key={ticket.id} className="flex items-center space-x-4 p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors">
                          <div className={`p-3 rounded-lg ${status.color} text-white`}>
                            <StatusIcon className="h-6 w-6" />
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold">Event Ticket #{ticket.id.slice(-8)}</h3>
                            <div className="flex items-center text-sm text-muted-foreground mt-1 space-x-4">
                              <span>{ticket.quantity} ticket{ticket.quantity > 1 ? 's' : ''}</span>
                              <span>•</span>
                              <span>KES {parseFloat(ticket.totalAmount).toLocaleString()}</span>
                              <span>•</span>
                              <span>{formatDate(ticket.createdAt || new Date())}</span>
                            </div>
                            {ticket.paymentMethod && (
                              <div className="text-xs text-muted-foreground mt-1">
                                Payment via {ticket.paymentMethod}
                              </div>
                            )}
                          </div>
                          <div className="flex items-center space-x-2">
                            <Badge 
                              variant={ticket.paymentStatus === "completed" ? "default" : "secondary"}
                              className={ticket.paymentStatus === "completed" ? "bg-green-500" : ""}
                            >
                              {status.label}
                            </Badge>
                            {ticket.paymentStatus === "completed" && (
                              <Button size="sm" variant="outline">
                                <Download className="h-4 w-4 mr-1" />
                                Download
                              </Button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Ticket className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-foreground mb-2">No Tickets Yet</h3>
                    <p className="text-muted-foreground mb-4">
                      Start exploring events and purchase your first ticket!
                    </p>
                    <Button asChild>
                      <a href="/events">Browse Events</a>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Events Tab (for organizers) */}
          {(user.role === "organizer" || user.role === "admin") && (
            <TabsContent value="events" className="space-y-6">
              <div className="flex justify-between items-center">
                <div>
                  <h2 className="text-2xl font-bold text-foreground">My Events</h2>
                  <p className="text-muted-foreground">Manage your events and track performance</p>
                </div>
                <Button className="btn-primary" asChild>
                  <a href="/create-event">
                    <Plus className="mr-2 h-4 w-4" />
                    Create Event
                  </a>
                </Button>
              </div>

              {eventsLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <Card key={i}>
                      <Skeleton className="h-48 w-full" />
                      <CardContent className="p-4">
                        <Skeleton className="h-6 w-3/4 mb-2" />
                        <Skeleton className="h-4 w-full mb-2" />
                        <Skeleton className="h-4 w-1/2" />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : userEvents?.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {userEvents.map((event: Event) => (
                    <div key={event.id} className="relative">
                      <EventCard event={event} />
                      <div className="absolute top-2 right-2 flex space-x-1">
                        <Button size="sm" variant="outline" className="bg-background/80 backdrop-blur-sm" asChild>
                          <a href={`/events/${event.id}`}>
                            <Eye className="h-3 w-3" />
                          </a>
                        </Button>
                        <Button size="sm" variant="outline" className="bg-background/80 backdrop-blur-sm">
                          <Edit className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Calendar className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">No Events Created</h3>
                  <p className="text-muted-foreground mb-4">
                    Create your first event and start selling tickets!
                  </p>
                  <Button asChild>
                    <a href="/create-event">Create Event</a>
                  </Button>
                </div>
              )}
            </TabsContent>
          )}

          {/* Donations Tab */}
          <TabsContent value="donations" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Heart className="h-5 w-5 mr-2 text-red-500" />
                  My Donations
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Track your contributions to the Flickshub Foundation
                </p>
              </CardHeader>
              <CardContent>
                {donationsLoading ? (
                  <div className="space-y-4">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <div key={i} className="flex items-center space-x-4 p-4 border border-border rounded-lg">
                        <Skeleton className="h-12 w-12 rounded-full" />
                        <div className="flex-1">
                          <Skeleton className="h-4 w-1/2 mb-2" />
                          <Skeleton className="h-3 w-1/3" />
                        </div>
                        <Skeleton className="h-6 w-16" />
                      </div>
                    ))}
                  </div>
                ) : donations?.length > 0 ? (
                  <div className="space-y-4">
                    {donations.map((donation: Donation) => (
                      <div key={donation.id} className="flex items-center space-x-4 p-4 border border-border rounded-lg">
                        <div className="p-3 rounded-full bg-red-100 text-red-600">
                          <Heart className="h-6 w-6" />
                        </div>
                        <div className="flex-1">
                          <div className="font-medium">
                            {donation.type === "round-up" ? "Round-up Donation" : "Direct Donation"}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {formatDate(donation.createdAt || new Date())} • via {donation.paymentMethod}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold text-green-600">
                            {donation.currency} {parseFloat(donation.amount).toLocaleString()}
                          </div>
                          <Badge 
                            variant={donation.status === "completed" ? "default" : "secondary"}
                            className={donation.status === "completed" ? "bg-green-500" : ""}
                          >
                            {donation.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Heart className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-foreground mb-2">No Donations Yet</h3>
                    <p className="text-muted-foreground mb-4">
                      Start making a difference in Kenyan communities!
                    </p>
                    <Button asChild>
                      <a href="/foundation">Make a Donation</a>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Profile Settings</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Update your personal information and preferences
                </p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleProfileUpdate} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        value={profileData.firstName}
                        onChange={(e) => setProfileData(prev => ({ ...prev, firstName: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        value={profileData.lastName}
                        onChange={(e) => setProfileData(prev => ({ ...prev, lastName: e.target.value }))}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={profileData.email}
                      onChange={(e) => setProfileData(prev => ({ ...prev, email: e.target.value }))}
                      disabled
                    />
                    <p className="text-xs text-muted-foreground mt-1">
                      Email cannot be changed. Contact support if needed.
                    </p>
                  </div>

                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      value={profileData.phone}
                      onChange={(e) => setProfileData(prev => ({ ...prev, phone: e.target.value }))}
                      placeholder="+254 XXX XXX XXX"
                    />
                  </div>

                  <div>
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea
                      id="bio"
                      value={profileData.bio}
                      onChange={(e) => setProfileData(prev => ({ ...prev, bio: e.target.value }))}
                      placeholder="Tell us about yourself..."
                      rows={3}
                    />
                  </div>

                  <Button 
                    type="submit" 
                    className="btn-primary"
                    disabled={updateProfileMutation.isPending}
                  >
                    {updateProfileMutation.isPending ? "Updating..." : "Update Profile"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Account Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="font-medium">Account Type</div>
                      <div className="text-sm text-muted-foreground capitalize">{user.role}</div>
                    </div>
                    <Badge variant="secondary">{user.role}</Badge>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="font-medium">Member Since</div>
                      <div className="text-sm text-muted-foreground">
                        {formatDate(user.createdAt || new Date())}
                      </div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="font-medium">Account Status</div>
                      <div className="text-sm text-muted-foreground">Active</div>
                    </div>
                    <Badge className="bg-green-500">Active</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <Footer />
      <MobileNav />
      <AiChat context="general" />
    </div>
  );
}
