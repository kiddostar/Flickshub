import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import MobileNav from "@/components/mobile-nav";
import EventCard from "@/components/event-card";
import AiChat from "@/components/ai-chat";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { Search, Filter, Calendar, MapPin, SlidersHorizontal, X } from "lucide-react";
import type { Event } from "@shared/schema";

export default function Events() {
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [showSponsored, setShowSponsored] = useState(false);
  const [sortBy, setSortBy] = useState("date");

  useEffect(() => {
    document.title = "Events - Flickshub";
    
    // Parse URL parameters
    const params = new URLSearchParams(window.location.search);
    const search = params.get("search");
    const category = params.get("category");
    const sponsored = params.get("sponsored");
    
    if (search) setSearchQuery(search);
    if (category) setSelectedCategory(category);
    if (sponsored === "true") setShowSponsored(true);
  }, [location]);

  // Build query parameters
  const buildQueryParams = () => {
    const params = new URLSearchParams();
    if (searchQuery) params.set("search", searchQuery);
    if (selectedCategory) params.set("category", selectedCategory);
    if (showSponsored) params.set("sponsored", "true");
    return params.toString();
  };

  const { data: events, isLoading, error } = useQuery({
    queryKey: ["/api/events", { search: searchQuery, category: selectedCategory, sponsored: showSponsored }],
    queryFn: () => {
      const queryParams = buildQueryParams();
      return fetch(`/api/events${queryParams ? `?${queryParams}` : ""}`).then(res => {
        if (!res.ok) throw new Error("Failed to fetch events");
        return res.json();
      });
    }
  });

  const categories = [
    { value: "", label: "All Categories" },
    { value: "music", label: "Music & Concerts" },
    { value: "tech", label: "Technology" },
    { value: "business", label: "Business & Networking" },
    { value: "arts", label: "Arts & Culture" },
    { value: "sports", label: "Sports & Recreation" },
    { value: "education", label: "Education & Workshops" },
    { value: "charity", label: "Charity & Fundraising" },
    { value: "food", label: "Food & Dining" }
  ];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // The query will automatically refetch due to the dependency on searchQuery
  };

  const clearFilters = () => {
    setSearchQuery("");
    setSelectedCategory("");
    setShowSponsored(false);
    setSortBy("date");
  };

  const sortedEvents = events ? [...events].sort((a: Event, b: Event) => {
    switch (sortBy) {
      case "price-low":
        return parseFloat(a.price) - parseFloat(b.price);
      case "price-high":
        return parseFloat(b.price) - parseFloat(a.price);
      case "name":
        return a.title.localeCompare(b.title);
      case "date":
      default:
        return new Date(a.date).getTime() - new Date(b.date).getTime();
    }
  }) : [];

  const activeFiltersCount = [searchQuery, selectedCategory, showSponsored].filter(Boolean).length;

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Header */}
      <section className="bg-gradient-to-r from-primary/10 to-primary/5 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-foreground mb-4">Discover Events</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Find amazing experiences happening around you
            </p>
          </div>
        </div>
      </section>

      {/* Filters and Search */}
      <section className="py-8 bg-background border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <form onSubmit={handleSearch} className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
                <Input
                  type="text"
                  placeholder="Search events, venues, or organizers..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-3 text-lg"
                />
              </div>
            </form>

            {/* Filters */}
            <div className="flex flex-wrap gap-4">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-48">
                  <Filter className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-48">
                  <SlidersHorizontal className="mr-2 h-4 w-4" />
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="date">Date (Earliest First)</SelectItem>
                  <SelectItem value="name">Name (A-Z)</SelectItem>
                  <SelectItem value="price-low">Price (Low to High)</SelectItem>
                  <SelectItem value="price-high">Price (High to Low)</SelectItem>
                </SelectContent>
              </Select>

              <Button
                variant={showSponsored ? "default" : "outline"}
                onClick={() => setShowSponsored(!showSponsored)}
                className={showSponsored ? "btn-primary" : ""}
              >
                Featured Events
              </Button>

              {activeFiltersCount > 0 && (
                <Button variant="ghost" onClick={clearFilters} className="text-muted-foreground">
                  <X className="mr-2 h-4 w-4" />
                  Clear ({activeFiltersCount})
                </Button>
              )}
            </div>
          </div>

          {/* Active Filters */}
          {activeFiltersCount > 0 && (
            <div className="flex flex-wrap gap-2 mt-4">
              {searchQuery && (
                <Badge variant="secondary" className="text-sm">
                  Search: "{searchQuery}"
                  <X 
                    className="ml-2 h-3 w-3 cursor-pointer" 
                    onClick={() => setSearchQuery("")}
                  />
                </Badge>
              )}
              {selectedCategory && (
                <Badge variant="secondary" className="text-sm">
                  Category: {categories.find(c => c.value === selectedCategory)?.label}
                  <X 
                    className="ml-2 h-3 w-3 cursor-pointer" 
                    onClick={() => setSelectedCategory("")}
                  />
                </Badge>
              )}
              {showSponsored && (
                <Badge variant="secondary" className="text-sm">
                  Featured Only
                  <X 
                    className="ml-2 h-3 w-3 cursor-pointer" 
                    onClick={() => setShowSponsored(false)}
                  />
                </Badge>
              )}
            </div>
          )}
        </div>
      </section>

      {/* Events Grid */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {error ? (
            <div className="text-center py-12">
              <Calendar className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">Error Loading Events</h3>
              <p className="text-muted-foreground mb-4">
                We encountered an issue while fetching events. Please try again.
              </p>
              <Button onClick={() => window.location.reload()}>Retry</Button>
            </div>
          ) : isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {Array.from({ length: 12 }).map((_, i) => (
                <Card key={i}>
                  <Skeleton className="h-48 w-full" />
                  <CardContent className="p-4">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-1/2 mb-3" />
                    <Skeleton className="h-8 w-1/3" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : sortedEvents.length > 0 ? (
            <>
              <div className="flex justify-between items-center mb-6">
                <p className="text-muted-foreground">
                  Showing {sortedEvents.length} event{sortedEvents.length !== 1 ? 's' : ''}
                  {activeFiltersCount > 0 && ' matching your filters'}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {sortedEvents.map((event: Event) => (
                  <EventCard key={event.id} event={event} />
                ))}
              </div>
            </>
          ) : (
            <div className="text-center py-12">
              <Calendar className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">No Events Found</h3>
              <p className="text-muted-foreground mb-4">
                {activeFiltersCount > 0 
                  ? "Try adjusting your filters to find more events."
                  : "There are no events available at the moment. Check back soon!"
                }
              </p>
              {activeFiltersCount > 0 && (
                <Button variant="outline" onClick={clearFilters}>
                  Clear Filters
                </Button>
              )}
            </div>
          )}
        </div>
      </section>

      <Footer />
      <MobileNav />
      <AiChat context="general" />
    </div>
  );
}
