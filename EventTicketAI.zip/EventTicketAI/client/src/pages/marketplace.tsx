import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import MobileNav from "@/components/mobile-nav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Search, 
  Filter, 
  Star, 
  MapPin, 
  Phone, 
  Mail, 
  Utensils, 
  Car, 
  Music, 
  Megaphone,
  Camera,
  Palette,
  Gift,
  Flower2,
  Users,
  Verified,
  ExternalLink
} from "lucide-react";
import type { Vendor } from "@shared/schema";

export default function Marketplace() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("");

  useEffect(() => {
    document.title = "Marketplace - Flickshub";
  }, []);

  const { data: vendors, isLoading, error } = useQuery({
    queryKey: ["/api/vendors", { category: selectedCategory }],
    queryFn: () => {
      const params = selectedCategory ? `?category=${selectedCategory}` : "";
      return fetch(`/api/vendors${params}`).then(res => {
        if (!res.ok) throw new Error("Failed to fetch vendors");
        return res.json();
      });
    }
  });

  const categories = [
    { value: "", label: "All Categories", icon: Users, color: "bg-gray-100 text-gray-600" },
    { value: "food", label: "Food & Catering", icon: Utensils, color: "bg-orange-100 text-orange-600" },
    { value: "transport", label: "Transportation", icon: Car, color: "bg-blue-100 text-blue-600" },
    { value: "entertainment", label: "Entertainment", icon: Music, color: "bg-purple-100 text-purple-600" },
    { value: "marketing", label: "Marketing", icon: Megaphone, color: "bg-green-100 text-green-600" },
    { value: "photography", label: "Photography", icon: Camera, color: "bg-pink-100 text-pink-600" },
    { value: "decoration", label: "Decoration", icon: Palette, color: "bg-yellow-100 text-yellow-600" },
    { value: "gifts", label: "Gifts & Favors", icon: Gift, color: "bg-red-100 text-red-600" },
    { value: "flowers", label: "Flowers & Plants", icon: Flower2, color: "bg-emerald-100 text-emerald-600" }
  ];

  const filteredVendors = vendors?.filter((vendor: Vendor) => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      vendor.businessName.toLowerCase().includes(query) ||
      vendor.description?.toLowerCase().includes(query) ||
      vendor.services?.some(service => service.toLowerCase().includes(query))
    );
  }) || [];

  const featuredServices = [
    {
      title: "Complete Event Packages",
      description: "Full-service event planning from start to finish",
      icon: Users,
      vendors: "25+ vendors",
      priceRange: "KES 50,000+"
    },
    {
      title: "Wedding Specialists",
      description: "Make your special day unforgettable",
      icon: Gift,
      vendors: "15+ vendors",
      priceRange: "KES 100,000+"
    },
    {
      title: "Corporate Events",
      description: "Professional services for business events",
      icon: Megaphone,
      vendors: "20+ vendors",
      priceRange: "KES 30,000+"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Header */}
      <section className="bg-gradient-to-r from-primary/10 to-primary/5 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-foreground mb-4">Event Services Marketplace</h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Connect with trusted vendors and partners to make your event extraordinary
            </p>
          </div>
        </div>
      </section>

      {/* Featured Services */}
      <section className="py-12 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-foreground mb-8">Featured Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            {featuredServices.map((service, index) => {
              const Icon = service.icon;
              return (
                <Card key={index} className="card-hover">
                  <CardContent className="p-6 text-center">
                    <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Icon className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-2">{service.title}</h3>
                    <p className="text-muted-foreground mb-4">{service.description}</p>
                    <div className="flex justify-between items-center text-sm text-muted-foreground mb-4">
                      <span>{service.vendors}</span>
                      <span className="font-semibold text-primary">{service.priceRange}</span>
                    </div>
                    <Button variant="outline" className="w-full">
                      Explore Services
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Uber Partnership Banner */}
          <div className="bg-gradient-to-r from-primary to-primary/80 rounded-2xl p-8 text-primary-foreground text-center mb-12">
            <h3 className="text-2xl font-bold mb-4">Partner with Uber for Seamless Transportation</h3>
            <p className="text-lg mb-6 opacity-90">
              Exclusive discounts for event attendees with direct app integration
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button variant="secondary" className="bg-white text-primary hover:bg-white/90">
                <Car className="mr-2 h-5 w-5" />
                Connect with Uber
                <ExternalLink className="ml-2 h-4 w-4" />
              </Button>
              <Badge variant="secondary" className="bg-yellow-300 text-yellow-800 text-sm font-semibold">
                Save up to 15% on rides to events
              </Badge>
            </div>
          </div>
        </div>
      </section>

      {/* Search and Filters */}
      <section className="py-8 bg-muted/50 border-y border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
                <Input
                  type="text"
                  placeholder="Search vendors, services, or specialties..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-3 text-lg"
                />
              </div>
            </div>
            
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-64">
                <Filter className="mr-2 h-4 w-4" />
                <SelectValue placeholder="Filter by category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => {
                  const Icon = category.icon;
                  return (
                    <SelectItem key={category.value} value={category.value}>
                      <div className="flex items-center">
                        <Icon className="mr-2 h-4 w-4" />
                        {category.label}
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>
        </div>
      </section>

      {/* Service Categories Grid */}
      <section className="py-12 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-foreground mb-8">Browse by Category</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            {categories.slice(1).map((category) => {
              const Icon = category.icon;
              return (
                <Button
                  key={category.value}
                  variant={selectedCategory === category.value ? "default" : "outline"}
                  className={`h-24 flex-col space-y-2 ${selectedCategory === category.value ? "btn-primary" : ""}`}
                  onClick={() => setSelectedCategory(selectedCategory === category.value ? "" : category.value)}
                >
                  <Icon className="h-6 w-6" />
                  <span className="text-xs text-center">{category.label}</span>
                </Button>
              );
            })}
          </div>

          {/* Vendors Grid */}
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-foreground">
              {selectedCategory ? `${categories.find(c => c.value === selectedCategory)?.label} Vendors` : "All Vendors"}
            </h2>
            {filteredVendors.length > 0 && (
              <p className="text-muted-foreground">
                {filteredVendors.length} vendor{filteredVendors.length !== 1 ? 's' : ''} found
              </p>
            )}
          </div>

          {error ? (
            <div className="text-center py-12">
              <Users className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">Error Loading Vendors</h3>
              <p className="text-muted-foreground mb-4">We couldn't load the vendors. Please try again.</p>
              <Button onClick={() => window.location.reload()}>Retry</Button>
            </div>
          ) : isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 9 }).map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <Skeleton className="w-12 h-12 rounded-full mr-4" />
                      <div className="flex-1">
                        <Skeleton className="h-5 w-3/4 mb-2" />
                        <Skeleton className="h-4 w-1/2" />
                      </div>
                    </div>
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-2/3 mb-4" />
                    <Skeleton className="h-8 w-full" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : filteredVendors.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredVendors.map((vendor: Vendor) => {
                const categoryInfo = categories.find(c => c.value === vendor.category);
                const CategoryIcon = categoryInfo?.icon || Users;
                
                return (
                  <Card key={vendor.id} className="card-hover">
                    <CardContent className="p-6">
                      <div className="flex items-center mb-4">
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center mr-4 ${categoryInfo?.color || "bg-gray-100 text-gray-600"}`}>
                          <CategoryIcon className="h-6 w-6" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-foreground flex items-center">
                            {vendor.businessName}
                            {vendor.isVerified && (
                              <Verified className="h-4 w-4 ml-2 text-blue-500" />
                            )}
                          </h3>
                          <p className="text-sm text-muted-foreground capitalize">
                            {vendor.category.replace('_', ' ')}
                          </p>
                        </div>
                      </div>

                      {vendor.rating > 0 && (
                        <div className="flex items-center mb-3">
                          <div className="flex text-yellow-400 mr-2">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star 
                                key={i} 
                                className={`h-4 w-4 ${i < Math.floor(vendor.rating) ? "fill-current" : ""}`} 
                              />
                            ))}
                          </div>
                          <span className="text-sm text-muted-foreground">
                            {vendor.rating.toFixed(1)} ({vendor.reviewCount} reviews)
                          </span>
                        </div>
                      )}

                      <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                        {vendor.description || "Professional service provider"}
                      </p>

                      {vendor.services && vendor.services.length > 0 && (
                        <div className="mb-4">
                          <div className="flex flex-wrap gap-1">
                            {vendor.services.slice(0, 3).map((service) => (
                              <Badge key={service} variant="secondary" className="text-xs">
                                {service}
                              </Badge>
                            ))}
                            {vendor.services.length > 3 && (
                              <Badge variant="secondary" className="text-xs">
                                +{vendor.services.length - 3} more
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}

                      <div className="space-y-2 mb-4">
                        {vendor.contactEmail && (
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Mail className="h-4 w-4 mr-2" />
                            <span className="truncate">{vendor.contactEmail}</span>
                          </div>
                        )}
                        {vendor.contactPhone && (
                          <div className="flex items-center text-sm text-muted-foreground">
                            <Phone className="h-4 w-4 mr-2" />
                            <span>{vendor.contactPhone}</span>
                          </div>
                        )}
                      </div>

                      <div className="flex justify-between items-center">
                        {vendor.priceRange && (
                          <span className="text-primary font-semibold text-sm">
                            {vendor.priceRange}
                          </span>
                        )}
                        <Button size="sm" className="btn-primary">
                          Contact Vendor
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12">
              <Users className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-foreground mb-2">No Vendors Found</h3>
              <p className="text-muted-foreground mb-4">
                {searchQuery || selectedCategory 
                  ? "Try adjusting your search or filter criteria."
                  : "No vendors are currently available in the marketplace."
                }
              </p>
              {(searchQuery || selectedCategory) && (
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedCategory("");
                  }}
                >
                  Clear Filters
                </Button>
              )}
            </div>
          )}
        </div>
      </section>

      <Footer />
      <MobileNav />
    </div>
  );
}
