import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import MobileNav from "@/components/mobile-nav";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { 
  Calendar, 
  MapPin, 
  Users, 
  Clock, 
  Star, 
  Share2, 
  Heart,
  Ticket,
  AlertCircle,
  CheckCircle,
  Minus,
  Plus
} from "lucide-react";
import type { Event } from "@shared/schema";

export default function EventDetails() {
  const [match, params] = useRoute("/events/:id");
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [ticketQuantity, setTicketQuantity] = useState(1);
  const [donationAmount, setDonationAmount] = useState("");
  const [roundUpDonation, setRoundUpDonation] = useState(false);

  useEffect(() => {
    if (match && params?.id) {
      document.title = "Event Details - Flickshub";
    }
  }, [match, params]);

  const { data: event, isLoading, error } = useQuery({
    queryKey: ["/api/events", params?.id],
    queryFn: () => {
      if (!params?.id) throw new Error("No event ID");
      return fetch(`/api/events/${params.id}`).then(res => {
        if (!res.ok) throw new Error("Failed to fetch event");
        return res.json();
      });
    },
    enabled: !!params?.id
  });

  const createTicketMutation = useMutation({
    mutationFn: async (ticketData: any) => {
      const response = await apiRequest("POST", "/api/tickets", ticketData);
      return response.json();
    },
    onSuccess: (ticket) => {
      toast({
        title: "Ticket Reserved",
        description: "Redirecting to checkout...",
      });
      // Redirect to checkout with ticket ID
      window.location.href = `/checkout/${ticket.id}`;
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to reserve ticket",
        variant: "destructive"
      });
    }
  });

  if (!match || !params?.id) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <AlertCircle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-foreground mb-2">Event Not Found</h1>
          <p className="text-muted-foreground mb-4">The event you're looking for doesn't exist.</p>
          <Button asChild>
            <Link href="/events">Browse Events</Link>
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  const formatDate = (date: string | Date) => {
    return new Intl.DateTimeFormat("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    }).format(new Date(date));
  };

  const formatTime = (date: string | Date) => {
    return new Intl.DateTimeFormat("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true,
    }).format(new Date(date));
  };

  const calculateTotal = () => {
    const ticketPrice = parseFloat(event?.price || "0");
    const baseTotal = ticketPrice * ticketQuantity;
    let donationTotal = 0;

    if (roundUpDonation) {
      const roundedUp = Math.ceil(baseTotal / 100) * 100;
      donationTotal = roundedUp - baseTotal;
    } else if (donationAmount) {
      donationTotal = parseFloat(donationAmount) || 0;
    }

    return {
      ticketTotal: baseTotal,
      donationTotal,
      grandTotal: baseTotal + donationTotal
    };
  };

  const handleBuyTicket = () => {
    if (!isAuthenticated) {
      toast({
        title: "Please Sign In",
        description: "You need to be signed in to purchase tickets.",
        variant: "destructive"
      });
      window.location.href = "/api/login";
      return;
    }

    if (!event) return;

    const totals = calculateTotal();
    
    createTicketMutation.mutate({
      eventId: event.id,
      quantity: ticketQuantity,
      totalAmount: totals.ticketTotal.toString(),
      donationAmount: totals.donationTotal > 0 ? totals.donationTotal.toString() : undefined,
      paymentStatus: "pending"
    });
  };

  const handleShare = async () => {
    const url = window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({
          title: event?.title,
          text: event?.description,
          url: url
        });
      } catch (error) {
        // Fall back to clipboard
        navigator.clipboard.writeText(url);
        toast({
          title: "Link Copied",
          description: "Event link copied to clipboard"
        });
      }
    } else {
      navigator.clipboard.writeText(url);
      toast({
        title: "Link Copied",
        description: "Event link copied to clipboard"
      });
    }
  };

  const isEventFull = event?.maxAttendees && event.currentAttendees >= event.maxAttendees;
  const isEventPast = event && new Date(event.date) < new Date();
  const availableSpots = event?.maxAttendees ? event.maxAttendees - event.currentAttendees : null;

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {isLoading ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Skeleton className="h-64 w-full mb-6" />
              <Skeleton className="h-8 w-3/4 mb-4" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-2/3 mb-6" />
              <Skeleton className="h-32 w-full" />
            </div>
            <div>
              <Card>
                <CardContent className="p-6">
                  <Skeleton className="h-8 w-1/2 mb-4" />
                  <Skeleton className="h-24 w-full mb-4" />
                  <Skeleton className="h-10 w-full" />
                </CardContent>
              </Card>
            </div>
          </div>
        ) : error ? (
          <div className="text-center py-16">
            <AlertCircle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-foreground mb-2">Error Loading Event</h1>
            <p className="text-muted-foreground mb-4">We couldn't load this event. Please try again.</p>
            <Button onClick={() => window.location.reload()}>Retry</Button>
          </div>
        ) : event ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2">
              {/* Event Image */}
              {event.imageUrl && (
                <div className="relative mb-6">
                  <img
                    src={event.imageUrl}
                    alt={event.title}
                    className="w-full h-64 md:h-80 object-cover rounded-xl"
                  />
                  <div className="absolute top-4 left-4 flex gap-2">
                    {event.isSponsored && (
                      <Badge className="bg-primary text-primary-foreground">
                        SPONSORED
                      </Badge>
                    )}
                    {isEventFull && (
                      <Badge className="bg-red-500 text-white">
                        SOLD OUT
                      </Badge>
                    )}
                  </div>
                  <Button
                    variant="outline"
                    size="icon"
                    className="absolute top-4 right-4 bg-background/80 backdrop-blur-sm"
                    onClick={handleShare}
                  >
                    <Share2 className="h-4 w-4" />
                  </Button>
                </div>
              )}

              {/* Event Title and Info */}
              <div className="mb-6">
                <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                  {event.title}
                </h1>
                
                <div className="flex flex-wrap gap-4 text-muted-foreground mb-6">
                  <div className="flex items-center">
                    <Calendar className="h-5 w-5 mr-2" />
                    <div>
                      <div className="font-medium">{formatDate(event.date)}</div>
                      <div className="text-sm">{formatTime(event.date)}</div>
                    </div>
                  </div>
                  
                  <div className="flex items-center">
                    <MapPin className="h-5 w-5 mr-2" />
                    <span>{event.venue}</span>
                  </div>
                  
                  {event.maxAttendees && (
                    <div className="flex items-center">
                      <Users className="h-5 w-5 mr-2" />
                      <span>{event.currentAttendees}/{event.maxAttendees} attending</span>
                    </div>
                  )}
                </div>

                {/* Event Status */}
                {isEventPast ? (
                  <div className="flex items-center text-muted-foreground mb-4">
                    <Clock className="h-5 w-5 mr-2" />
                    <span>This event has ended</span>
                  </div>
                ) : isEventFull ? (
                  <div className="flex items-center text-red-600 mb-4">
                    <AlertCircle className="h-5 w-5 mr-2" />
                    <span>This event is sold out</span>
                  </div>
                ) : availableSpots && availableSpots <= 10 ? (
                  <div className="flex items-center text-orange-600 mb-4">
                    <AlertCircle className="h-5 w-5 mr-2" />
                    <span>Only {availableSpots} spots remaining!</span>
                  </div>
                ) : null}
              </div>

              {/* Event Description */}
              <Card>
                <CardHeader>
                  <CardTitle>About This Event</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground whitespace-pre-wrap">
                    {event.description || "No description available for this event."}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar - Ticket Purchase */}
            <div>
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Get Tickets</span>
                    <span className="text-2xl font-bold text-primary">
                      {event.currency} {parseFloat(event.price).toLocaleString()}
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {!isEventPast && !isEventFull ? (
                    <>
                      {/* Quantity Selector */}
                      <div>
                        <Label htmlFor="quantity">Number of Tickets</Label>
                        <div className="flex items-center space-x-2 mt-2">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => setTicketQuantity(Math.max(1, ticketQuantity - 1))}
                            disabled={ticketQuantity <= 1}
                          >
                            <Minus className="h-4 w-4" />
                          </Button>
                          <Input
                            id="quantity"
                            type="number"
                            value={ticketQuantity}
                            onChange={(e) => setTicketQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                            className="text-center"
                            min="1"
                            max={availableSpots || undefined}
                          />
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => setTicketQuantity(ticketQuantity + 1)}
                            disabled={availableSpots ? ticketQuantity >= availableSpots : false}
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      <Separator />

                      {/* Donation Options */}
                      <div>
                        <Label className="text-base font-semibold">Support Our Foundation</Label>
                        <p className="text-sm text-muted-foreground mb-3">
                          Add a donation to support local communities
                        </p>
                        
                        <div className="space-y-3">
                          <div className="flex items-center space-x-2">
                            <input
                              type="checkbox"
                              id="roundup"
                              checked={roundUpDonation}
                              onChange={(e) => {
                                setRoundUpDonation(e.target.checked);
                                if (e.target.checked) setDonationAmount("");
                              }}
                              className="rounded"
                            />
                            <Label htmlFor="roundup" className="text-sm">
                              Round up to nearest KES 100 
                              {roundUpDonation && ` (+KES ${calculateTotal().donationTotal})`}
                            </Label>
                          </div>
                          
                          <div>
                            <Label htmlFor="donation" className="text-sm">Custom Donation Amount</Label>
                            <Input
                              id="donation"
                              type="number"
                              placeholder="Enter amount"
                              value={donationAmount}
                              onChange={(e) => {
                                setDonationAmount(e.target.value);
                                if (e.target.value) setRoundUpDonation(false);
                              }}
                              disabled={roundUpDonation}
                              className="mt-1"
                            />
                          </div>
                        </div>
                      </div>

                      <Separator />

                      {/* Order Summary */}
                      <div>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span>Tickets ({ticketQuantity}x)</span>
                            <span>{event.currency} {calculateTotal().ticketTotal.toLocaleString()}</span>
                          </div>
                          {calculateTotal().donationTotal > 0 && (
                            <div className="flex justify-between text-green-600">
                              <span className="flex items-center">
                                <Heart className="h-4 w-4 mr-1" />
                                Donation
                              </span>
                              <span>{event.currency} {calculateTotal().donationTotal.toLocaleString()}</span>
                            </div>
                          )}
                          <Separator />
                          <div className="flex justify-between font-semibold text-lg">
                            <span>Total</span>
                            <span>{event.currency} {calculateTotal().grandTotal.toLocaleString()}</span>
                          </div>
                        </div>
                      </div>

                      {/* Purchase Button */}
                      <Button 
                        className="w-full btn-primary text-lg py-3"
                        onClick={handleBuyTicket}
                        disabled={createTicketMutation.isPending}
                      >
                        <Ticket className="mr-2 h-5 w-5" />
                        {createTicketMutation.isPending ? "Processing..." : "Buy Tickets"}
                      </Button>

                      {!isAuthenticated && (
                        <p className="text-sm text-muted-foreground text-center">
                          You'll be prompted to sign in before purchase
                        </p>
                      )}
                    </>
                  ) : (
                    <div className="text-center py-4">
                      {isEventPast ? (
                        <div className="text-muted-foreground">
                          <Clock className="h-12 w-12 mx-auto mb-2" />
                          <p>This event has ended</p>
                        </div>
                      ) : (
                        <div className="text-muted-foreground">
                          <AlertCircle className="h-12 w-12 mx-auto mb-2" />
                          <p>Tickets are no longer available</p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Event Tags */}
                  {event.tags && event.tags.length > 0 && (
                    <div>
                      <Label className="text-base font-semibold mb-2 block">Tags</Label>
                      <div className="flex flex-wrap gap-2">
                        {event.tags.map((tag) => (
                          <Badge key={tag} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        ) : null}
      </div>

      <Footer />
      <MobileNav />
    </div>
  );
}
