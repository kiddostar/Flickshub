import { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import MobileNav from "@/components/mobile-nav";
import AiChat from "@/components/ai-chat";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { format } from "date-fns";
import { Calendar as CalendarIcon, Clock, MapPin, Users, DollarSign, Tag, Bot, Sparkles, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

export default function CreateEvent() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    venue: "",
    date: undefined as Date | undefined,
    time: "",
    price: "",
    currency: "KES",
    maxAttendees: "",
    tags: [] as string[],
    imageUrl: ""
  });

  const [currentTag, setCurrentTag] = useState("");
  const [isSponsored, setIsSponsored] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState<any>(null);
  const [showAiHelper, setShowAiHelper] = useState(false);

  useEffect(() => {
    document.title = "Create Event - Flickshub";
    
    if (!isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to create events.",
        variant: "destructive"
      });
      window.location.href = "/api/login";
      return;
    }

    if (user && user.role !== "organizer" && user.role !== "admin") {
      toast({
        title: "Access Denied",
        description: "Only organizers can create events.",
        variant: "destructive"
      });
      window.location.href = "/";
      return;
    }
  }, [isAuthenticated, user, toast]);

  const createEventMutation = useMutation({
    mutationFn: async (eventData: any) => {
      const response = await apiRequest("POST", "/api/events", eventData);
      return response.json();
    },
    onSuccess: (event) => {
      toast({
        title: "Event Created",
        description: "Your event has been created successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      window.location.href = `/events/${event.id}`;
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create event",
        variant: "destructive"
      });
    }
  });

  const getAiSuggestionsMutation = useMutation({
    mutationFn: async (prompt: string) => {
      const response = await apiRequest("POST", "/api/ai/plan-event", {
        eventName: formData.title || "My Event",
        budget: parseFloat(formData.price) * (parseInt(formData.maxAttendees) || 100) || 100000,
        eventType: formData.tags[0] || "general",
        expectedAttendees: parseInt(formData.maxAttendees) || undefined,
        location: formData.venue || "Kenya"
      });
      return response.json();
    },
    onSuccess: (suggestions) => {
      setAiSuggestions(suggestions);
      toast({
        title: "AI Suggestions Ready",
        description: "Check the AI assistant panel for recommendations!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "AI Error",
        description: "Failed to get AI suggestions. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addTag = () => {
    if (currentTag.trim() && !formData.tags.includes(currentTag.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, currentTag.trim()]
      }));
      setCurrentTag("");
    }
  };

  const removeTag = (tagToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.venue || !formData.date || !formData.time || !formData.price) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    // Combine date and time
    const [hours, minutes] = formData.time.split(':');
    const eventDateTime = new Date(formData.date);
    eventDateTime.setHours(parseInt(hours), parseInt(minutes));

    const eventData = {
      title: formData.title,
      description: formData.description,
      venue: formData.venue,
      date: eventDateTime.toISOString(),
      price: formData.price,
      currency: formData.currency,
      maxAttendees: formData.maxAttendees ? parseInt(formData.maxAttendees) : undefined,
      imageUrl: formData.imageUrl || undefined,
      tags: formData.tags.length > 0 ? formData.tags : undefined,
      isSponsored
    };

    createEventMutation.mutate(eventData);
  };

  const getAiSuggestions = () => {
    if (!formData.title) {
      toast({
        title: "Event Name Required",
        description: "Please enter an event name to get AI suggestions.",
        variant: "destructive"
      });
      return;
    }
    getAiSuggestionsMutation.mutate("");
  };

  const categories = [
    "Music & Concerts",
    "Technology",
    "Business & Networking",
    "Arts & Culture",
    "Sports & Recreation",
    "Education & Workshops",
    "Charity & Fundraising",
    "Food & Dining",
    "Fashion & Beauty",
    "Health & Wellness"
  ];

  if (!isAuthenticated || (user && user.role !== "organizer" && user.role !== "admin")) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="max-w-4xl mx-auto px-4 py-16 text-center">
          <AlertCircle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-foreground mb-2">Access Restricted</h1>
          <p className="text-muted-foreground">Only organizers can create events.</p>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Create New Event</CardTitle>
                <p className="text-muted-foreground">
                  Fill in the details below to create your event. Use our AI assistant for recommendations!
                </p>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Basic Information */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Basic Information</h3>
                    
                    <div>
                      <Label htmlFor="title">Event Title *</Label>
                      <Input
                        id="title"
                        value={formData.title}
                        onChange={(e) => handleInputChange("title", e.target.value)}
                        placeholder="Enter a compelling event title"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        value={formData.description}
                        onChange={(e) => handleInputChange("description", e.target.value)}
                        placeholder="Describe what makes your event special..."
                        rows={4}
                      />
                    </div>

                    <div>
                      <Label htmlFor="imageUrl">Event Image URL</Label>
                      <Input
                        id="imageUrl"
                        type="url"
                        value={formData.imageUrl}
                        onChange={(e) => handleInputChange("imageUrl", e.target.value)}
                        placeholder="https://example.com/image.jpg"
                      />
                    </div>
                  </div>

                  <Separator />

                  {/* Event Details */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Event Details</h3>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label>Event Date *</Label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant="outline"
                              className={cn(
                                "w-full justify-start text-left font-normal",
                                !formData.date && "text-muted-foreground"
                              )}
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {formData.date ? format(formData.date, "PPP") : "Pick a date"}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar
                              mode="single"
                              selected={formData.date}
                              onSelect={(date) => handleInputChange("date", date)}
                              initialFocus
                              disabled={(date) => date < new Date()}
                            />
                          </PopoverContent>
                        </Popover>
                      </div>

                      <div>
                        <Label htmlFor="time">Event Time *</Label>
                        <div className="relative">
                          <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                          <Input
                            id="time"
                            type="time"
                            value={formData.time}
                            onChange={(e) => handleInputChange("time", e.target.value)}
                            className="pl-10"
                            required
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="venue">Venue *</Label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                        <Input
                          id="venue"
                          value={formData.venue}
                          onChange={(e) => handleInputChange("venue", e.target.value)}
                          placeholder="Enter venue name and location"
                          className="pl-10"
                          required
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="price">Ticket Price *</Label>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground text-sm font-medium">KES</span>
                          <Input
                            id="price"
                            type="number"
                            value={formData.price}
                            onChange={(e) => handleInputChange("price", e.target.value)}
                            placeholder="0.00"
                            className="pl-12"
                            min="0"
                            step="0.01"
                            required
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="currency">Currency</Label>
                        <Select value={formData.currency} onValueChange={(value) => handleInputChange("currency", value)}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="KES">KES (Kenyan Shilling)</SelectItem>
                            <SelectItem value="USD">USD (US Dollar)</SelectItem>
                            <SelectItem value="EUR">EUR (Euro)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="maxAttendees">Maximum Attendees</Label>
                      <div className="relative">
                        <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                        <Input
                          id="maxAttendees"
                          type="number"
                          value={formData.maxAttendees}
                          onChange={(e) => handleInputChange("maxAttendees", e.target.value)}
                          placeholder="Leave empty for unlimited"
                          className="pl-10"
                          min="1"
                        />
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Tags and Categories */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Categories & Tags</h3>
                    
                    <div>
                      <Label>Add Tags</Label>
                      <div className="flex gap-2 mt-2">
                        <Input
                          value={currentTag}
                          onChange={(e) => setCurrentTag(e.target.value)}
                          placeholder="Enter a tag"
                          onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addTag())}
                        />
                        <Button type="button" onClick={addTag} variant="outline">
                          <Tag className="h-4 w-4 mr-2" />
                          Add
                        </Button>
                      </div>
                      
                      {formData.tags.length > 0 && (
                        <div className="flex flex-wrap gap-2 mt-3">
                          {formData.tags.map((tag) => (
                            <Badge key={tag} variant="secondary" className="cursor-pointer" onClick={() => removeTag(tag)}>
                              {tag} ×
                            </Badge>
                          ))}
                        </div>
                      )}
                    </div>

                    <div>
                      <Label>Quick Categories</Label>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mt-2">
                        {categories.map((category) => (
                          <Button
                            key={category}
                            type="button"
                            variant={formData.tags.includes(category) ? "default" : "outline"}
                            size="sm"
                            onClick={() => {
                              if (formData.tags.includes(category)) {
                                removeTag(category);
                              } else {
                                setFormData(prev => ({
                                  ...prev,
                                  tags: [...prev.tags, category]
                                }));
                              }
                            }}
                          >
                            {category}
                          </Button>
                        ))}
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Advanced Options */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Advanced Options</h3>
                    
                    {user?.role === "admin" && (
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="sponsored"
                          checked={isSponsored}
                          onCheckedChange={setIsSponsored}
                        />
                        <Label htmlFor="sponsored">Mark as Sponsored Event</Label>
                      </div>
                    )}
                  </div>

                  <Separator />

                  {/* Submit Button */}
                  <div className="flex gap-4">
                    <Button 
                      type="submit" 
                      className="btn-primary flex-1"
                      disabled={createEventMutation.isPending}
                    >
                      {createEventMutation.isPending ? "Creating..." : "Create Event"}
                    </Button>
                    <Button type="button" variant="outline" asChild>
                      <a href="/dashboard">Cancel</a>
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* AI Assistant Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Bot className="h-5 w-5 mr-2" />
                  AI Event Assistant
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Get AI-powered suggestions for your event planning, including budget breakdown, venue recommendations, and marketing strategies.
                </p>
                
                <Button 
                  onClick={getAiSuggestions}
                  disabled={getAiSuggestionsMutation.isPending || !formData.title}
                  className="w-full"
                  variant="outline"
                >
                  <Sparkles className="h-4 w-4 mr-2" />
                  {getAiSuggestionsMutation.isPending ? "Getting Suggestions..." : "Get AI Suggestions"}
                </Button>

                {aiSuggestions && (
                  <div className="space-y-4 mt-4">
                    <h4 className="font-semibold">Budget Breakdown</h4>
                    <div className="space-y-2 text-sm">
                      {Object.entries(aiSuggestions.budgetBreakdown || {}).map(([category, amount]) => (
                        <div key={category} className="flex justify-between">
                          <span className="capitalize">{category}:</span>
                          <span className="font-medium">KES {(amount as number).toLocaleString()}</span>
                        </div>
                      ))}
                    </div>

                    {aiSuggestions.venueRecommendations && aiSuggestions.venueRecommendations.length > 0 && (
                      <>
                        <h4 className="font-semibold">Recommended Venues</h4>
                        <div className="space-y-2">
                          {aiSuggestions.venueRecommendations.slice(0, 3).map((venue: any, index: number) => (
                            <div key={index} className="p-2 bg-muted rounded text-sm">
                              <div className="font-medium">{venue.name}</div>
                              <div className="text-muted-foreground">{venue.location}</div>
                              <div className="text-primary">KES {venue.pricePerDay?.toLocaleString()}/day</div>
                            </div>
                          ))}
                        </div>
                      </>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Event Creation Tips</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-1.5"></div>
                  <p>Write a compelling title that clearly describes your event</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-1.5"></div>
                  <p>Include high-quality images to attract more attendees</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-1.5"></div>
                  <p>Set realistic pricing based on your target audience</p>
                </div>
                <div className="flex items-start space-x-2">
                  <div className="w-2 h-2 bg-primary rounded-full mt-1.5"></div>
                  <p>Use relevant tags to help people discover your event</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Footer />
      <MobileNav />
      <AiChat context="event-planning" initialMessage={formData.title ? `Help me plan my event: ${formData.title}` : undefined} />
    </div>
  );
}
