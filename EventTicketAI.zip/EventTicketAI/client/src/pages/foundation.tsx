import { useEffect, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import MobileNav from "@/components/mobile-nav";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest } from "@/lib/queryClient";
import { 
  Heart, 
  GraduationCap, 
  Stethoscope, 
  Sprout, 
  Users, 
  DollarSign,
  TrendingUp,
  Building,
  CreditCard,
  Smartphone,
  CheckCircle
} from "lucide-react";

export default function Foundation() {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [donationAmount, setDonationAmount] = useState("");
  const [customAmount, setCustomAmount] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"mpesa" | "stripe">("mpesa");
  const [roundUpEnabled, setRoundUpEnabled] = useState(false);

  useEffect(() => {
    document.title = "Flickshub Foundation - Making a Difference";
  }, []);

  const createDonationMutation = useMutation({
    mutationFn: async (donationData: any) => {
      if (paymentMethod === "stripe") {
        // Create Stripe payment intent
        const response = await apiRequest("POST", "/api/create-donation-intent", {
          amount: donationData.amount,
          currency: "kes"
        });
        const { clientSecret } = await response.json();
        
        // In a real app, you'd redirect to Stripe checkout
        toast({
          title: "Redirecting to Payment",
          description: "You will be redirected to complete your donation.",
        });
        
        return { success: true, paymentMethod: "stripe" };
      } else {
        // Handle M-Pesa donation
        const response = await apiRequest("POST", "/api/donations", donationData);
        return response.json();
      }
    },
    onSuccess: (result) => {
      toast({
        title: "Thank You!",
        description: "Your donation has been processed successfully.",
      });
      setDonationAmount("");
      setCustomAmount("");
    },
    onError: (error: Error) => {
      toast({
        title: "Donation Failed",
        description: error.message || "Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleDonation = (amount: string) => {
    if (!amount || parseFloat(amount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid donation amount.",
        variant: "destructive"
      });
      return;
    }

    createDonationMutation.mutate({
      amount: amount,
      currency: "KES",
      type: "one-time",
      paymentMethod: paymentMethod,
      userId: isAuthenticated ? undefined : null
    });
  };

  const presetAmounts = [
    { amount: "1000", description: "School supplies for 2 children" },
    { amount: "2500", description: "Monthly meals for a family" },
    { amount: "5000", description: "Medical care for a community" },
    { amount: "10000", description: "School fees for a semester" }
  ];

  const impactAreas = [
    {
      icon: GraduationCap,
      title: "Education Support",
      description: "Supporting over 500 children with school fees, supplies, and educational programs across rural Kenya.",
      impact: "500+ children helped",
      color: "text-green-600 bg-green-100"
    },
    {
      icon: Stethoscope,
      title: "Healthcare Access",
      description: "Mobile health clinics and medical camps reaching remote communities with essential healthcare services.",
      impact: "25 communities reached",
      color: "text-blue-600 bg-blue-100"
    },
    {
      icon: Sprout,
      title: "Community Development",
      description: "Clean water projects, sustainable agriculture training, and economic empowerment programs.",
      impact: "KES 2.5M funds raised",
      color: "text-primary bg-primary/10"
    }
  ];

  const impactStats = [
    { label: "Children Helped", value: "500+", icon: Users },
    { label: "Communities", value: "25", icon: Building },
    { label: "Funds Raised", value: "KES 2.5M", icon: TrendingUp },
    { label: "Success Rate", value: "98%", icon: CheckCircle }
  ];

  const corporatePrograms = [
    {
      title: "Employee Matching",
      description: "Many employers match charitable donations dollar-for-dollar",
      action: "Check if your company participates in matching programs"
    },
    {
      title: "Corporate Sponsorship",
      description: "Partner with us for event sponsorships and CSR initiatives",
      action: "Contact us for corporate partnership opportunities"
    },
    {
      title: "Volunteer Programs",
      description: "Organize team building activities while making a difference",
      action: "Schedule a corporate volunteer day"
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary/10 via-background to-primary/5 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
              Flickshub <span className="gradient-text">Foundation</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Making a difference in communities across Kenya, one event at a time
            </p>
            
            {/* Impact Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
              {impactStats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <Card key={index} className="text-center">
                    <CardContent className="p-4">
                      <Icon className="h-8 w-8 mx-auto mb-2 text-primary" />
                      <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                      <div className="text-sm text-muted-foreground">{stat.label}</div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Impact Areas */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Our Impact Areas</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Every donation directly supports these vital community programs
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            {impactAreas.map((area, index) => {
              const Icon = area.icon;
              return (
                <Card key={index} className="text-center card-hover">
                  <CardContent className="p-8">
                    <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${area.color}`}>
                      <Icon className="h-8 w-8" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-3">{area.title}</h3>
                    <p className="text-muted-foreground mb-4">{area.description}</p>
                    <Badge variant="secondary" className="text-sm font-medium">
                      {area.impact}
                    </Badge>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Image Gallery */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <img 
              src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
              alt="Children's education support"
              className="rounded-xl shadow-lg w-full h-48 object-cover"
            />
            <img 
              src="https://images.unsplash.com/photo-1593113598332-cd288d649433?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
              alt="Community development"
              className="rounded-xl shadow-lg w-full h-48 object-cover"
            />
            <img 
              src="https://images.unsplash.com/photo-1559027615-cd4628902d4a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
              alt="Healthcare outreach"
              className="rounded-xl shadow-lg w-full h-48 object-cover"
            />
            <img 
              src="https://images.unsplash.com/photo-1497486751825-1233686d5d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
              alt="Educational programs"
              className="rounded-xl shadow-lg w-full h-48 object-cover"
            />
          </div>
        </div>
      </section>

      {/* Donation Section */}
      <section className="py-16 bg-gradient-to-br from-primary/5 to-primary/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Make a Difference Today</h2>
            <p className="text-lg text-muted-foreground">
              Every contribution helps us create lasting positive impact in Kenyan communities
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* One-time Donation */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Heart className="h-5 w-5 mr-2 text-red-500" />
                  One-Time Donation
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Preset Amounts */}
                <div>
                  <Label className="text-base font-semibold mb-3 block">Choose an Amount</Label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {presetAmounts.map((preset) => (
                      <Button
                        key={preset.amount}
                        variant={donationAmount === preset.amount ? "default" : "outline"}
                        className={`p-4 h-auto text-left ${donationAmount === preset.amount ? "btn-primary" : ""}`}
                        onClick={() => {
                          setDonationAmount(preset.amount);
                          setCustomAmount("");
                        }}
                      >
                        <div>
                          <div className="font-semibold">KES {parseInt(preset.amount).toLocaleString()}</div>
                          <div className="text-sm opacity-80">{preset.description}</div>
                        </div>
                      </Button>
                    ))}
                  </div>
                </div>

                {/* Custom Amount */}
                <div>
                  <Label htmlFor="custom-amount" className="text-base font-semibold">Custom Amount</Label>
                  <div className="relative mt-2">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground text-sm font-medium">KES</span>
                    <Input
                      id="custom-amount"
                      type="number"
                      placeholder="Enter custom amount"
                      value={customAmount}
                      onChange={(e) => {
                        setCustomAmount(e.target.value);
                        setDonationAmount("");
                      }}
                      className="pl-12"
                      min="1"
                    />
                  </div>
                </div>

                <Separator />

                {/* Payment Methods */}
                <div>
                  <Label className="text-base font-semibold mb-3 block">Payment Method</Label>
                  <div className="flex gap-2">
                    <Button
                      variant={paymentMethod === "mpesa" ? "default" : "outline"}
                      className={`flex-1 ${paymentMethod === "mpesa" ? "bg-green-600 hover:bg-green-700" : ""}`}
                      onClick={() => setPaymentMethod("mpesa")}
                    >
                      <Smartphone className="mr-2 h-4 w-4" />
                      M-Pesa
                    </Button>
                    <Button
                      variant={paymentMethod === "stripe" ? "default" : "outline"}
                      className={`flex-1 ${paymentMethod === "stripe" ? "bg-blue-600 hover:bg-blue-700" : ""}`}
                      onClick={() => setPaymentMethod("stripe")}
                    >
                      <CreditCard className="mr-2 h-4 w-4" />
                      Card/Bank
                    </Button>
                  </div>
                </div>

                <Button 
                  onClick={() => handleDonation(customAmount || donationAmount)}
                  disabled={createDonationMutation.isPending || (!customAmount && !donationAmount)}
                  className="w-full btn-primary text-lg py-3"
                >
                  <Heart className="mr-2 h-5 w-5" />
                  {createDonationMutation.isPending ? "Processing..." : "Donate Now"}
                </Button>
              </CardContent>
            </Card>

            {/* Round-Up & Features */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2 text-primary" />
                  Round-Up Donations
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-muted-foreground">
                  Automatically round up your ticket purchases and donate the change to our foundation.
                </p>
                
                {/* Example */}
                <div className="bg-muted rounded-lg p-4">
                  <h5 className="font-semibold text-foreground mb-3">How it works:</h5>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Ticket Price:</span>
                      <span>KES 2,450</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Rounded to:</span>
                      <span>KES 2,500</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-semibold text-primary">
                      <span>Donation:</span>
                      <span>KES 50</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-primary/10 rounded-lg">
                  <div>
                    <div className="font-semibold text-foreground">Enable Round-Up</div>
                    <div className="text-sm text-muted-foreground">Activate for all future purchases</div>
                  </div>
                  <Switch
                    checked={roundUpEnabled}
                    onCheckedChange={setRoundUpEnabled}
                  />
                </div>

                {roundUpEnabled && (
                  <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
                    <div className="flex items-center text-green-700 dark:text-green-300">
                      <CheckCircle className="h-5 w-5 mr-2" />
                      <span className="font-medium">Round-up donations enabled!</span>
                    </div>
                    <p className="text-sm text-green-600 dark:text-green-400 mt-1">
                      Your future ticket purchases will automatically include round-up donations.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Corporate Programs */}
      <section className="py-16 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Corporate Partnerships</h2>
            <p className="text-lg text-muted-foreground">
              Partner with us to amplify your company's social impact
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {corporatePrograms.map((program, index) => (
              <Card key={index} className="card-hover">
                <CardContent className="p-6 text-center">
                  <h3 className="text-xl font-semibold text-foreground mb-3">{program.title}</h3>
                  <p className="text-muted-foreground mb-4">{program.description}</p>
                  <Button variant="outline" className="w-full">
                    {program.action}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-primary/5">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-foreground mb-4">
            Ready to Make a Difference?
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Join thousands of generous donors who are transforming communities across Kenya
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="btn-primary text-lg px-8 py-3">
              <Heart className="mr-2 h-5 w-5" />
              Start Donating
            </Button>
            <Button variant="outline" className="text-lg px-8 py-3">
              <Users className="mr-2 h-5 w-5" />
              Become a Volunteer
            </Button>
          </div>
        </div>
      </section>

      <Footer />
      <MobileNav />
    </div>
  );
}
