import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Search, Plus, ChevronDown } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

export default function HeroSection() {
  const { isAuthenticated, user } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/events?search=${encodeURIComponent(searchQuery)}`;
    }
  };

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')"
        }}
      />
      
      {/* Overlay */}
      <div className="absolute inset-0 hero-overlay" />
      
      {/* Content */}
      <div className="relative z-10 text-center text-white max-w-4xl px-4">
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
          Discover experiences that{" "}
          <span className="text-yellow-300">move you</span>
        </h1>
        <p className="text-lg md:text-xl lg:text-2xl mb-8 opacity-90 max-w-2xl mx-auto">
          From intimate gatherings to grand celebrations, find your next unforgettable moment
        </p>
        
        {/* Search Bar */}
        <form onSubmit={handleSearch} className="max-w-2xl mx-auto mb-8">
          <div className="flex flex-col sm:flex-row gap-3 bg-white/10 backdrop-blur-md rounded-2xl p-3">
            <input
              type="text"
              placeholder="Search for events, venues, or experiences..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 bg-transparent text-white placeholder-white/70 border-none outline-none px-4 py-3 text-lg"
            />
            <Button 
              type="submit" 
              className="btn-primary px-8 py-3 text-lg font-semibold shadow-xl"
            >
              <Search className="mr-2 h-5 w-5" />
              Search
            </Button>
          </div>
        </form>
        
        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button className="btn-primary px-8 py-4 text-lg font-semibold shadow-xl" asChild>
            <Link href="/events">
              <Search className="mr-2 h-5 w-5" />
              Browse Events
            </Link>
          </Button>
          
          {isAuthenticated && (user?.role === "organizer" || user?.role === "admin") && (
            <Button 
              variant="outline" 
              className="border-2 border-white text-white bg-transparent hover:bg-white hover:text-foreground px-8 py-4 text-lg font-semibold transition-all" 
              asChild
            >
              <Link href="/create-event">
                <Plus className="mr-2 h-5 w-5" />
                Create Event
              </Link>
            </Button>
          )}
          
          {!isAuthenticated && (
            <Button 
              variant="outline" 
              className="border-2 border-white text-white bg-transparent hover:bg-white hover:text-foreground px-8 py-4 text-lg font-semibold transition-all" 
              asChild
            >
              <a href="/api/login">
                <Plus className="mr-2 h-5 w-5" />
                Get Started
              </a>
            </Button>
          )}
        </div>

        {/* Features Highlight */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 text-sm opacity-80">
          <div className="flex items-center justify-center space-x-2">
            <div className="w-2 h-2 bg-yellow-300 rounded-full"></div>
            <span>AI-Powered Event Planning</span>
          </div>
          <div className="flex items-center justify-center space-x-2">
            <div className="w-2 h-2 bg-yellow-300 rounded-full"></div>
            <span>Secure Payment Processing</span>
          </div>
          <div className="flex items-center justify-center space-x-2">
            <div className="w-2 h-2 bg-yellow-300 rounded-full"></div>
            <span>Charity Integration</span>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white animate-bounce">
        <ChevronDown className="h-6 w-6 opacity-70" />
      </div>
    </section>
  );
}
