import { Calendar, MapPin, Users, Star, Clock } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { Event } from "@shared/schema";

interface EventCardProps {
  event: Event;
  variant?: "default" | "featured" | "compact";
  showCountdown?: boolean;
}

export default function EventCard({ event, variant = "default", showCountdown = false }: EventCardProps) {
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    }).format(new Date(date));
  };

  const formatTime = (date: Date) => {
    return new Intl.DateTimeFormat("en-US", {
      hour: "2-digit",
      minute: "2-digit",
    }).format(new Date(date));
  };

  const getTimeUntilEvent = () => {
    const now = new Date();
    const eventDate = new Date(event.date);
    const diffTime = eventDate.getTime() - now.getTime();
    
    if (diffTime < 0) return null;
    
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    const diffHours = Math.ceil((diffTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const diffMinutes = Math.ceil((diffTime % (1000 * 60 * 60)) / (1000 * 60));
    
    if (diffDays > 0) return { days: diffDays, hours: diffHours, minutes: diffMinutes };
    if (diffHours > 0) return { days: 0, hours: diffHours, minutes: diffMinutes };
    return { days: 0, hours: 0, minutes: diffMinutes };
  };

  const timeUntil = showCountdown ? getTimeUntilEvent() : null;
  const isEventSoon = timeUntil && timeUntil.days <= 7;
  const soldOutPercentage = event.maxAttendees ? (event.currentAttendees / event.maxAttendees) * 100 : 0;
  const isAlmostSoldOut = soldOutPercentage >= 90;

  if (variant === "compact") {
    return (
      <Link href={`/events/${event.id}`}>
        <div className="bg-card rounded-xl shadow-md overflow-hidden card-hover border border-border">
          {event.imageUrl && (
            <div className="relative h-40">
              <img 
                src={event.imageUrl} 
                alt={event.title}
                className="w-full h-full object-cover"
              />
              {isAlmostSoldOut && (
                <Badge className="absolute top-3 left-3 bg-red-500 text-white animate-pulse-slow">
                  <Clock className="w-3 h-3 mr-1" />
                  {Math.round(100 - soldOutPercentage)}% Left
                </Badge>
              )}
            </div>
          )}
          <div className="p-4">
            <h4 className="font-semibold text-card-foreground mb-1 truncate">{event.title}</h4>
            <p className="text-sm text-muted-foreground mb-2 truncate">{event.venue}</p>
            <p className="text-lg font-bold text-primary">
              {event.currency} {parseFloat(event.price).toLocaleString()}
            </p>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <div className={`bg-card rounded-2xl shadow-lg overflow-hidden card-hover border ${
      event.isSponsored ? "border-primary border-2" : "border-border"
    }`}>
      <div className="relative">
        {event.imageUrl && (
          <img 
            src={event.imageUrl} 
            alt={event.title}
            className={`w-full object-cover ${variant === "featured" ? "h-48" : "h-40"}`}
          />
        )}
        
        {/* Badges */}
        <div className="absolute top-4 left-4 flex flex-col gap-2">
          {isEventSoon && (
            <Badge className="bg-red-500 text-white animate-pulse-slow">
              <Star className="w-3 h-3 mr-1" />
              Trending
            </Badge>
          )}
          {isAlmostSoldOut && (
            <Badge className="bg-yellow-500 text-white animate-pulse-slow">
              <Clock className="w-3 h-3 mr-1" />
              {Math.round(100 - soldOutPercentage)}% Left
            </Badge>
          )}
        </div>
        
        {event.isSponsored && (
          <Badge className="absolute top-4 right-4 bg-primary text-primary-foreground">
            SPONSORED
          </Badge>
        )}
      </div>
      
      <div className={`p-${variant === "featured" ? "6" : "4"}`}>
        <h3 className={`font-bold text-card-foreground mb-2 ${
          variant === "featured" ? "text-xl" : "text-lg"
        }`}>
          {event.title}
        </h3>
        <p className="text-muted-foreground mb-4 line-clamp-2">{event.description}</p>
        
        <div className="flex items-center mb-4 text-sm text-muted-foreground flex-wrap gap-2">
          <div className="flex items-center">
            <Calendar className="w-4 h-4 mr-1" />
            <span>{formatDate(event.date)}</span>
          </div>
          <span className="text-border">•</span>
          <div className="flex items-center">
            <MapPin className="w-4 h-4 mr-1" />
            <span>{event.venue}</span>
          </div>
          {event.maxAttendees && (
            <>
              <span className="text-border">•</span>
              <div className="flex items-center">
                <Users className="w-4 h-4 mr-1" />
                <span>{event.currentAttendees}/{event.maxAttendees}</span>
              </div>
            </>
          )}
        </div>

        {/* Countdown Timer for Featured Events */}
        {showCountdown && timeUntil && variant === "featured" && (
          <div className="bg-muted rounded-lg p-4 mb-4">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-2">Event starts in:</p>
              <div className="flex justify-center space-x-4 text-primary font-bold">
                <div className="text-center">
                  <div className="text-2xl">{timeUntil.days}</div>
                  <div className="text-xs">DAYS</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl">{timeUntil.hours}</div>
                  <div className="text-xs">HRS</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl">{timeUntil.minutes}</div>
                  <div className="text-xs">MIN</div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        <div className="flex justify-between items-center">
          <div>
            <p className="text-2xl font-bold text-primary">
              {event.currency} {parseFloat(event.price).toLocaleString()}
            </p>
            <p className="text-sm text-muted-foreground">From</p>
          </div>
          <Button className="btn-primary" asChild>
            <Link href={`/events/${event.id}`}>
              View Details
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
